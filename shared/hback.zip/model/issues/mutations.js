const {
  GraphQLNonNull,
  GraphQLString,
  GraphQLList,
  GraphQLID,
  GraphQLInt,
  GraphQLFloat,
  GraphQLBoolean,
} = require("graphql");
const GraphQLJSON = require("graphql-type-json").GraphQLJSON;
const type = require("./type").schema;

const o_list_schema = require("./type").o_list_schema;
const Issue = require("./issues");
// Defines the mutations
module.exports = {
  submitIssue: {
    type,
    args: {
      booking_id: { type: new GraphQLNonNull(GraphQLInt) },
      user_id: { type: new GraphQLNonNull(GraphQLInt) },
      message: { type: new GraphQLNonNull(GraphQLString) },
      issue_subject_id: { type: new GraphQLNonNull(GraphQLInt) },
      issue_sub_subject_id: { type: GraphQLInt },
      image: { type: GraphQLString },
    },
    resolve: async (parent, args) => {
      return Issue.submitIssue(args);
    },
  },
  submitIssueChat: {
    type,
    args: {
      issue_id: { type: new GraphQLNonNull(GraphQLInt) },
      user_id: { type: new GraphQLNonNull(GraphQLInt) },
      message: { type: new GraphQLNonNull(GraphQLString) },
    },
    resolve: async (parent, args) => {
      return Issue.submitIssueChat(args);
    },
  },
};
