const {
  GraphQLList,
  GraphQLID,
  GraphQLString,
  GraphQLNonNull,
  GraphQLFloat,
  GraphQLObjectType,
  GraphQLInt,
} = require("graphql");
const type = require("./type").schema;
const { common_fields } = require("./type");
const User = require("./issues");
const Commonlib = require("../../lib/query");
const Issue = require("./issues");
const mySQLWrapper = require("../../lib/mysqlWrapper");
// Defines the queries

module.exports = {
  getIssueSubject: {
    type,
    resolve: async (parent) => {
      var baseQuery =
        "SELECT id,subject,status from issue_reason where status='1' and reason_for='1' order by id";
      var issue_subject_list = await mySQLWrapper.createQuery({
        query: baseQuery,
      });
      if (issue_subject_list) {
        return {
          list: issue_subject_list,
          statusCode: 200,
          message: "Issue Subject List",
        };
      } else {
        const error = new Error("No reason found");
        error.code = 404;
        throw error;
      }
    },
  },
  getIssueSubSubject: {
    type,
    args: {
      issue_reason_id: { type: new GraphQLNonNull(GraphQLInt) },
    },
    resolve: async (parent, args) => {
      return Issue.getIssueSubSubject(args);
    },
  },
  getIssueChat: {
    type,
    args: {
      issue_id: { type: new GraphQLNonNull(GraphQLInt) },
    },
    resolve: async (parent, args) => {
      return Issue.getIssueChat(args);
    },
  },
};
