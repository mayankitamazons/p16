let {
  GraphQLID,
  GraphQLString,
  GraphQLFloat,
  GraphQLInt,
  GraphQLObjectType,
  GraphQLNonNull,
  GraphQLList,
  GraphQLEnumType,
  GraphQLBoolean,
} = require("graphql");
const GraphQLJSON = require("graphql-type-json").GraphQLJSON;

var common_fields = {
  list: {
    type: GraphQLJSON,
  },
  statusCode: {
    type: GraphQLInt,
  },
  coupon_id: {
    type: GraphQLInt,
  },
  discount_amount: {
    type: GraphQLInt,
  },
  refferal_wallet_used: {
    type: GraphQLBoolean,
  },
  message: {
    type: GraphQLString,
  },
};

// Defines the type
var c_schema = new GraphQLObjectType({
  name: "Offer",
  description: "Offer list",
  fields: common_fields,
});

module.exports = {
  schema: c_schema,
  common_fields: common_fields,
};
