const {
  GraphQLList,
  GraphQLID,
  GraphQLString,
  GraphQLNonNull,
  GraphQLInt,
  GraphQLObjectType,
} = require("graphql");
const type = require("./type").schema;

// var Commonlib = require("../../lib/commonlib");
const Query = require("../../lib/query");
const GraphQLJSON = require("graphql-type-json").GraphQLJSON;

// Defines the queries

module.exports = {
  helpmenu: {
    type: new GraphQLList(type),
    //resolve: Servicelist.getByID.bind(Servicelist)
    resolve: async (parent) => {
      var p_order = { by: "display_order_no", direction: "ASC" };
      const result = await Query.findByFields(
        "help_menus",
        {
          status: "1",
          available_for_customer: "1",
        },
        100,
        p_order
      );
      // console.log(result);
      return result;
    },
  },
};
