const {
  GraphQLList,
  GraphQLID,
  GraphQLString,
  GraphQLNonNull,
  GraphQLFloat,
  GraphQLObjectType,
  GraphQLInt,
} = require('graphql');
const type = require('./type').schema;
const verification_schema = require('./type').verification_schema;
const { validate, ValidationError } = require('validator-fluent');
const { errorName } = require('../../middleware/errorContant');

const Function = require('./function');

// Defines the queries
var c_fields = {
  statusCode: {
    type: GraphQLInt,
  },
  message: {
    type: GraphQLString,
  },
};
var home_schema = new GraphQLObjectType({
  name: 'BaseModel',
  description: 'Base model',
  fields: c_fields,
});
module.exports = {
  vehiclelist: {
    type: new GraphQLList(type),
    // type,
    description: 'All vehicle Data for driver id',
    args: { 
      driver_id: { type: GraphQLInt },
     },
    resolve: async (parent, args, { verifiedUser }) => {
      // resolve(parent, args) {
      if (!verifiedUser) {
        var err = new Error(errorName.UNAUTHRIZED);
        throw err;
        // throw new Error("Unauthenticated");
      } else {
        const [data, errors] = validate(args, (value) => ({
          driver_id: value('driver_id').notEmpty(),
        }));
        if (Object.keys(errors).length > 0) {
          throw new ValidationError(errors);
        } else {
          args.token_user_id = verifiedUser.user_id;
          return Function.findall(args);
        }
      }
    },
  },
  vehicle: {
    type,
    description: 'Retrieves one vehicle Data',
    args: { 
      vehicle_id: { type: GraphQLID },
      driver_id: { type: GraphQLInt },
     },
    resolve: async (parent, args, { verifiedUser }) => {
      // resolve(parent, args) {
        // verifiedUser.id=1;
      if (!verifiedUser) {
        var err = new Error(errorName.UNAUTHRIZED);
        throw err;
        // throw new Error("Unauthenticated");
      } else {
        const [data, errors] = validate(args, (value) => ({
          vehicle_id: value('vehicle_id').notEmpty(),
          driver_id: value('driver_id').notEmpty(),
        }));
        if (Object.keys(errors).length > 0) {
          throw new ValidationError(errors);
        } else {
          args.token_user_id = verifiedUser.user_id;
          return Function.vehicledetail(args);
        }
      }
    },
  },

 
};
