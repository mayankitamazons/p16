const {
  GraphQLString,
  GraphQLID,
  GraphQLInt,
  GraphQLBoolean,
  GraphQLNonNull,
} = require('graphql');
const { validate, ValidationError } = require('validator-fluent');
// import { validate, ValidationError } from "validator-fluent";
const type = require('./type').schema;

const common_fields = require('./type').common_fields;
const Function = require('./function');
const { errorName } = require('../../middleware/errorContant');

module.exports = {
  addvehicle: {
    type,
    description: 'Register new Vehicle for driver',
    args: {
    driver_id: { type: GraphQLInt },
    model: { type: GraphQLString },
    vehicle_type: { type: GraphQLString },
    photo: { type: GraphQLString },
    color: { type: GraphQLString },
    model_year: { type: GraphQLString },
    luggage_status: { type: GraphQLString },
    backrow_seating_status: { type: GraphQLString },
    others: { type: GraphQLString },
    registration_number: { type: GraphQLString },
    total_seat: { type: GraphQLInt },
    fuel_type: { type: GraphQLString },
    ac: { type: GraphQLString }
    },
    resolve: async (parent, args, { verifiedUser }) => {
      if (!verifiedUser) {
        var err = new Error(errorName.UNAUTHRIZED);
        throw err;
      }
      else{
        const [data, errors] = validate(args, (value) => ({
          driver_id: value('driver_id')
            .notEmpty(),
            model: value('model').notEmpty().isLength({ min: 3, max: 25 }),
            vehicle_type: value('vehicle_type').notEmpty().isLength({ min: 3, max: 25 }),
            color: value('color').notEmpty(),
          
        }));
  
        if (Object.keys(errors).length > 0) {
          throw new ValidationError(errors);
        } else {
          args.token_user_id=verifiedUser.user_id;
          return Function.addvehicle(args);
        }
      }
      
    },
  },
  updatevehicle: {
    type,
    description: 'update vehicle',
    args: {
      vehicle_id: { type: GraphQLInt },
      driver_id: { type: GraphQLInt },
      model: { type: GraphQLString },
      vehicle_type: { type: GraphQLString },
      photo: { type: GraphQLString },
      color: { type: GraphQLString },
      model_year: { type: GraphQLString },
      luggage_status: { type: GraphQLString },
      backrow_seating_status: { type: GraphQLString },
      others: { type: GraphQLString },
      registration_number: { type: GraphQLString },
      total_seat: { type: GraphQLInt },
      fuel_type: { type: GraphQLString },
      ac: { type: GraphQLString },
      status: { type: GraphQLBoolean }
    },
    resolve: async (parent, args, { verifiedUser }) => {
      // console.log("req args", args);
      if (!verifiedUser) {
        var err = new Error(errorName.UNAUTHRIZED);
        throw err;
      } else {
        const [data, errors] = validate(args, (value) => ({
          vehicle_id: value('vehicle_id').notEmpty(),
          driver_id: value('driver_id').notEmpty(),
        }));

        if (Object.keys(errors).length > 0) {
          throw new ValidationError(errors);
        } else {
          args.token_user_id = verifiedUser.user_id;
          return Function.updatevehicle(args);
        }
      }
    },
  },
 
};
