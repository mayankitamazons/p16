-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 15, 2023 at 12:04 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db`
--

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `trip_id` int(11) DEFAULT NULL,
  `rider_id` int(11) DEFAULT NULL,
  `booked_seat` int(11) DEFAULT NULL,
  `from_location` varchar(255) DEFAULT NULL,
  `from_lat` varchar(255) DEFAULT NULL,
  `from_lng` varchar(255) DEFAULT NULL,
  `destination_address` varchar(255) DEFAULT NULL,
  `destination_lat` varchar(255) DEFAULT NULL,
  `destination_lng` varchar(255) DEFAULT NULL,
  `base_fare` int(11) DEFAULT NULL,
  `extra_amount` int(11) DEFAULT NULL,
  `discount_amount` int(11) DEFAULT NULL,
  `total_fare` int(11) DEFAULT NULL,
  `coupon_id` int(11) DEFAULT NULL,
  `coupon_code` varchar(255) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `payment_status` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0 Means Pending\r\n1 Means Success',
  `booking_status` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL DEFAULT '0' COMMENT '0 Means Pending\r\n1 Means Active\r\n2 Means Completed\r\n3 Means Cancelled' CHECK (json_valid(`booking_status`)),
  `remark` varchar(255) DEFAULT NULL COMMENT 'Remark when cancelled',
  `cancelled_by` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0 Means Rider\r\n1 Means Driver',
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `booking_payments`
--

CREATE TABLE `booking_payments` (
  `id` int(11) NOT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `transaction_id` varchar(255) DEFAULT NULL,
  `transaction_date_time` datetime DEFAULT NULL,
  `transaction_message` varchar(255) DEFAULT NULL,
  `transaction_status` enum('0','1','2','3','4','5') NOT NULL DEFAULT '0',
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `help_menus`
--

CREATE TABLE `help_menus` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `short_desc` varchar(255) DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `available_for_customer` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0- no , 1 - yes',
  `available_for_partner` enum('0','1') NOT NULL DEFAULT '0',
  `slug` varchar(255) DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1',
  `display_order_no` int(11) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_by` int(11) DEFAULT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `help_menus`
--

INSERT INTO `help_menus` (`id`, `title`, `short_desc`, `icon`, `available_for_customer`, `available_for_partner`, `slug`, `status`, `display_order_no`, `created_by`, `created`, `modified_by`, `modified`) VALUES
(1, 'Booking Services', 'Booked Service related issues', '', '1', '0', NULL, '1', 2, 52, '2021-10-12 00:42:14', 55, '2022-02-01 16:40:23'),
(2, 'Paying for services', 'Paying for services', '', '1', '0', NULL, '1', 3, 52, '2021-10-12 00:42:14', 55, '2022-01-13 11:29:37'),
(3, 'Leads', 'Leads, Notification ', 'https://res.cloudinary.com/the-assisto/image/upload/v1635577297/icons8-file-64_lg69fc.png', '0', '1', NULL, '1', 0, NULL, '2021-10-13 04:17:34', 55, '2022-01-08 13:00:26'),
(4, 'Responded jobs', ' Jobs, Booking', 'https://res.cloudinary.com/the-assisto/image/upload/v1635577280/icons8-briefcase-64_j3lctq.png', '0', '1', NULL, '0', 4, NULL, '2021-10-13 04:17:34', 55, '2022-01-08 13:05:50'),
(5, 'Earnings', 'Payout issue', 'https://res.cloudinary.com/the-assisto/image/upload/v1635574394/icons8-get-money-64_gjah0r.png', '0', '1', NULL, '1', NULL, NULL, '2021-10-13 04:17:34', 55, '2021-10-30 11:43:19'),
(6, 'Credits / Penalty', 'Credits info and Penalty info', 'https://res.cloudinary.com/the-assisto/image/upload/v1635573950/icons8-rupee-64_n3fi55.png', '0', '1', NULL, '0', NULL, NULL, '2021-10-13 04:17:34', 55, '2021-10-30 11:36:54'),
(7, 'Product Order', 'PPE/Order, Delivery status', 'https://res.cloudinary.com/the-assisto/image/upload/v1635575236/icons8-in-transit-50_ybttmm.png', '0', '1', NULL, '1', NULL, NULL, '2021-10-13 04:17:34', 55, '2021-10-30 11:57:42'),
(8, 'PPE Kit Related isuse', 'Mask', 'https://res.cloudinary.com/the-assisto/image/upload/v1635575348/icons8-protection-mask-64_qddgvn.png', '0', '1', NULL, '0', NULL, NULL, '2021-10-13 04:17:34', 55, '2021-10-30 11:59:12'),
(9, 'Profile', 'Add / Edit Profile', 'https://res.cloudinary.com/the-assisto/image/upload/v1635577218/icons8-user-90_sjzyxj.png', '0', '1', NULL, '1', NULL, NULL, '2021-10-13 04:17:34', 55, '2021-10-30 12:30:21'),
(10, 'Welcome ', 'About updated', 'https://res.cloudinary.com/the-assisto/image/upload/v1634559800/Screenshot_1_jx6jo5.png', '1', '0', NULL, '1', 10, 55, '2021-10-18 06:54:32', 55, '2022-01-20 17:40:39'),
(11, 'Others', 'Hiring, Office address', 'https://res.cloudinary.com/the-assisto/image/upload/v1635576635/icons8-four-squares-48_qfghcx.png', '0', '1', NULL, '1', NULL, 55, '2021-10-30 01:20:44', 55, '2021-10-30 12:20:45'),
(13, 'test', 'test dec', 'https://res.cloudinary.com/the-assisto/image/upload/v1641020426/Men1_yvvudb_couypx.png', '1', '0', NULL, '0', 6, 55, '2022-01-01 01:30:32', 55, '2022-01-18 11:45:28'),
(14, 'Covid-19 safety', 'Covid-19 safety', '', '1', '0', NULL, '1', 7, 55, '2022-01-13 00:30:10', 55, '2022-01-18 12:06:46'),
(15, 'Booked services', 'Booked services', '', '1', '0', NULL, '1', 4, 55, '2022-01-13 00:32:30', 55, '2022-01-13 11:32:30');

-- --------------------------------------------------------

--
-- Table structure for table `help_question_answers`
--

CREATE TABLE `help_question_answers` (
  `id` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT NULL COMMENT 'Comes if this question have parent question',
  `help_menu_id` int(11) DEFAULT NULL,
  `question` varchar(255) DEFAULT NULL,
  `answer` text DEFAULT NULL,
  `clikable_slug` varchar(255) DEFAULT NULL,
  `display_order_no` int(11) DEFAULT NULL,
  `status` enum('0','1') NOT NULL DEFAULT '1' COMMENT '1-active , 0 - not active',
  `created_by` int(11) DEFAULT NULL,
  `created` timestamp NOT NULL DEFAULT current_timestamp(),
  `modified_by` int(11) DEFAULT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `help_question_answers`
--

INSERT INTO `help_question_answers` (`id`, `parent_id`, `help_menu_id`, `question`, `answer`, `clikable_slug`, `display_order_no`, `status`, `created_by`, `created`, `modified_by`, `modified`) VALUES
(1, NULL, 1, 'How to book services ?', '<p>1. Search for the category.<br />2. Select the services you want to opt for.<br />3. Provide the Address for services.<br />4. Book the Date and Time slot as per your requirement.<br />5. Complete the payment procedure, and your service is booked.<br />6. An Expert will be assigned to you within &ldquo;2&rdquo; hours.</p>', '', 1, '1', NULL, '2021-10-12 00:45:19', 55, '2022-01-13 11:04:53'),
(2, NULL, 1, 'How to cancel a booking ?', '<p>1. Visit the booking section.<br />2. Select the booking you want to cancel.<br />3. Click on the &lsquo;Cancel&rsquo;.<br />4. Select the reason for the cancellation and it\'s done.</p>\r\n<p><strong>Note:-</strong> We recommend you reschedule your booking according to your convenience.</p>', '', 2, '1', NULL, '2021-10-12 00:45:19', 55, '2022-01-13 11:06:04'),
(3, NULL, 3, 'Why I am not getting the leads ?', '<p><strong><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" there=\"\" can=\"\" be=\"\" multiple=\"multiple\" reasons=\"\" for=\"\" not=\"\" generating=\"\" lead=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\">There can be multiple reasons for not generating leads.</span></strong></p>\r\n<ol>\r\n<li>Your credit might be less than 100 (recharge your credit).</li>\r\n<li>Leads are not generating in your area.</li>\r\n<li>The penalty limit might be crossed (contact to Category manager).</li>\r\n<li>Your rating might be below the average.</li>\r\n<li>There can be specific complaint against you.</li>\r\n</ol>', '1', 1, '1', NULL, '2021-10-12 00:45:19', 55, '2022-01-12 17:17:24'),
(4, NULL, 10, 'How to cancel a service ??', '<p>Answer for service booking updated final</p>', '1', NULL, '1', NULL, '2021-10-12 00:45:19', 55, '2021-10-26 12:16:28'),
(5, NULL, NULL, 'How to use wallet amount?', '<p>Click on the wallet icon and use the wallet amount.</p>', '1', NULL, '1', 55, '2021-12-31 23:24:19', 55, '2022-01-01 10:24:20'),
(6, NULL, NULL, 'How to use wallet amount?', '<p>Click on the wallet icon and use the wallet amount.</p>', '2', NULL, '1', 55, '2022-01-01 00:00:02', 55, '2022-01-01 11:00:04'),
(7, NULL, NULL, 'Test', '<p>test</p>', '', NULL, '1', 55, '2022-01-01 00:26:35', 55, '2022-01-01 11:26:37'),
(8, NULL, NULL, 'test qna', '<p>ss</p>', '', NULL, '1', 55, '2022-01-01 01:31:24', 55, '2022-01-01 12:31:26'),
(9, NULL, NULL, 'Test qna', '<p>dd</p>', '', NULL, '1', 55, '2022-01-01 01:33:33', 55, '2022-01-01 12:33:34'),
(10, NULL, NULL, 'fff', '<p>dss</p>', '', NULL, '1', 55, '2022-01-01 01:33:51', 55, '2022-01-01 12:33:53'),
(11, NULL, NULL, 'ddd', '<p>ddd</p>', '', NULL, '1', 55, '2022-01-01 01:34:56', 55, '2022-01-01 12:34:58'),
(12, NULL, NULL, 'ddd', '<p>ddd</p>', '', NULL, '1', 55, '2022-01-01 01:35:04', 55, '2022-01-01 12:35:05'),
(13, NULL, NULL, 'test qna', '<p>ddd</p>', '', NULL, '1', 55, '2022-01-01 01:41:06', 55, '2022-01-01 12:41:08'),
(14, NULL, NULL, 'te', '<p>ss</p>', '', NULL, '1', 55, '2022-01-01 01:41:38', 55, '2022-01-01 12:41:40'),
(15, NULL, NULL, 'test qna', '<p>xxxaa</p>', '', NULL, '1', 55, '2022-01-01 01:44:45', 55, '2022-01-01 12:44:47'),
(16, NULL, NULL, 'dds', '<p>sss</p>', '', NULL, '1', 55, '2022-01-01 01:46:28', 55, '2022-01-01 12:46:30'),
(17, NULL, NULL, 'dds', '<p>sss</p>', '', NULL, '1', 55, '2022-01-01 01:46:38', 55, '2022-01-01 12:46:40'),
(18, NULL, NULL, 'How can I cancel my lead?', '<ol>\r\n<li><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;1. Visit the \'Leads\' section.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:833,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;11&quot;:4,&quot;12&quot;:0}\">Visit the \'Leads\' section.</span></li>\r\n<li><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;1. Visit the \'Leads\' section.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:833,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;11&quot;:4,&quot;12&quot;:0}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;2. Select the job you want to cancel.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\">2. Select the job you want to cancel.</span></span></li>\r\n<li><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;1. Visit the \'Leads\' section.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:833,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;11&quot;:4,&quot;12&quot;:0}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;2. Select the job you want to cancel.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;3. You will find a cancel button to \'Cancel\' the job.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\">3. You will find a cancel button to \'Cancel\' the job.</span></span></span></li>\r\n<li><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;1. Visit the \'Leads\' section.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:833,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;11&quot;:4,&quot;12&quot;:0}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;2. Select the job you want to cancel.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;3. You will find a cancel button to \'Cancel\' the job.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;4. Select the reason for cancellation of the job and submit it.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\">4. Select the reason for cancellation of the job and submit it.</span></span></span></span></li>\r\n<li><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;1. Visit the \'Leads\' section.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:833,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;11&quot;:4,&quot;12&quot;:0}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;2. Select the job you want to cancel.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;3. You will find a cancel button to \'Cancel\' the job.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;4. Select the reason for cancellation of the job and submit it.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;5. Your job will be cancelled.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\">5. Your job will be cancelled.</span></span></span></span></span></li>\r\n</ol>\r\n<p><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;1. Visit the \'Leads\' section.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:833,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;11&quot;:4,&quot;12&quot;:0}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;2. Select the job you want to cancel.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;3. You will find a cancel button to \'Cancel\' the job.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;4. Select the reason for cancellation of the job and submit it.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;5. Your job will be cancelled.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;Note:- No Charge if you cancel until 2 hours before the service \\nAfter that, a cancellation fee of Rs 50 will apply.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\">Note:- No Charge if you cancel until 2 hours before the service <br />After that, a cancellation fee of Rs 50 will apply.</span></span></span></span></span></span></p>', '', NULL, '1', 55, '2022-01-08 01:21:51', 55, '2022-01-08 12:21:52'),
(19, NULL, NULL, 'How can I cancel my lead?', '<ol>\r\n<li><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;1. Visit the \'Leads\' section.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:833,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;11&quot;:4,&quot;12&quot;:0}\">Visit the \'Leads\' section.</span></li>\r\n<li><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;1. Visit the \'Leads\' section.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:833,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;11&quot;:4,&quot;12&quot;:0}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;2. Select the job you want to cancel.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\">2. Select the job you want to cancel.</span></span></li>\r\n<li><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;1. Visit the \'Leads\' section.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:833,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;11&quot;:4,&quot;12&quot;:0}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;2. Select the job you want to cancel.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;3. You will find a cancel button to \'Cancel\' the job.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\">3. You will find a cancel button to \'Cancel\' the job.</span></span></span></li>\r\n<li><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;1. Visit the \'Leads\' section.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:833,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;11&quot;:4,&quot;12&quot;:0}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;2. Select the job you want to cancel.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;3. You will find a cancel button to \'Cancel\' the job.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;4. Select the reason for cancellation of the job and submit it.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\">4. Select the reason for cancellation of the job and submit it.</span></span></span></span></li>\r\n<li><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;1. Visit the \'Leads\' section.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:833,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;11&quot;:4,&quot;12&quot;:0}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;2. Select the job you want to cancel.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;3. You will find a cancel button to \'Cancel\' the job.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;4. Select the reason for cancellation of the job and submit it.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;5. Your job will be cancelled.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\">5. Your job will be cancelled.</span></span></span></span></span></li>\r\n</ol>\r\n<p><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;1. Visit the \'Leads\' section.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:833,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;11&quot;:4,&quot;12&quot;:0}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;2. Select the job you want to cancel.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;3. You will find a cancel button to \'Cancel\' the job.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;4. Select the reason for cancellation of the job and submit it.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;5. Your job will be cancelled.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;Note:- No Charge if you cancel until 2 hours before the service \\nAfter that, a cancellation fee of Rs 50 will apply.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\">Note:- No Charge if you cancel until 2 hours before the service <br />After that, a cancellation fee of Rs 50 will apply.</span></span></span></span></span></span></p>', '', NULL, '1', 55, '2022-01-08 01:22:04', 55, '2022-01-08 12:22:05'),
(20, NULL, NULL, 'How can I cancel my lead?', '<ol>\r\n<li><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;1. Visit the \'Leads\' section.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:833,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;11&quot;:4,&quot;12&quot;:0}\">Visit the \'Leads\' section.</span></li>\r\n<li><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;1. Visit the \'Leads\' section.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:833,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;11&quot;:4,&quot;12&quot;:0}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;2. Select the job you want to cancel.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\">2. Select the job you want to cancel.</span></span></li>\r\n<li><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;1. Visit the \'Leads\' section.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:833,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;11&quot;:4,&quot;12&quot;:0}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;2. Select the job you want to cancel.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;3. You will find a cancel button to \'Cancel\' the job.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\">3. You will find a cancel button to \'Cancel\' the job.</span></span></span></li>\r\n<li><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;1. Visit the \'Leads\' section.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:833,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;11&quot;:4,&quot;12&quot;:0}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;2. Select the job you want to cancel.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;3. You will find a cancel button to \'Cancel\' the job.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;4. Select the reason for cancellation of the job and submit it.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\">4. Select the reason for cancellation of the job and submit it.</span></span></span></span></li>\r\n<li><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;1. Visit the \'Leads\' section.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:833,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;11&quot;:4,&quot;12&quot;:0}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;2. Select the job you want to cancel.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;3. You will find a cancel button to \'Cancel\' the job.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;4. Select the reason for cancellation of the job and submit it.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;5. Your job will be cancelled.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\">5. Your job will be cancelled.</span></span></span></span></span></li>\r\n</ol>\r\n<p><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;1. Visit the \'Leads\' section.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:833,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;11&quot;:4,&quot;12&quot;:0}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;2. Select the job you want to cancel.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;3. You will find a cancel button to \'Cancel\' the job.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;4. Select the reason for cancellation of the job and submit it.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;5. Your job will be cancelled.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;Note:- No Charge if you cancel until 2 hours before the service \\nAfter that, a cancellation fee of Rs 50 will apply.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\">Note:- No Charge if you cancel until 2 hours before the service <br />After that, a cancellation fee of Rs 50 will apply.</span></span></span></span></span></span></p>', '', NULL, '1', 55, '2022-01-08 01:22:10', 55, '2022-01-08 12:22:11'),
(21, NULL, NULL, 'How can I cancel my lead?', '<ol>\r\n<li><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;1. Visit the \'Leads\' section.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:833,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;11&quot;:4,&quot;12&quot;:0}\">Visit the \'Leads\' section.</span></li>\r\n<li><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;1. Visit the \'Leads\' section.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:833,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;11&quot;:4,&quot;12&quot;:0}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;2. Select the job you want to cancel.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\">2. Select the job you want to cancel.</span></span></li>\r\n<li><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;1. Visit the \'Leads\' section.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:833,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;11&quot;:4,&quot;12&quot;:0}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;2. Select the job you want to cancel.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;3. You will find a cancel button to \'Cancel\' the job.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\">3. You will find a cancel button to \'Cancel\' the job.</span></span></span></li>\r\n<li><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;1. Visit the \'Leads\' section.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:833,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;11&quot;:4,&quot;12&quot;:0}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;2. Select the job you want to cancel.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;3. You will find a cancel button to \'Cancel\' the job.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;4. Select the reason for cancellation of the job and submit it.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\">4. Select the reason for cancellation of the job and submit it.</span></span></span></span></li>\r\n<li><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;1. Visit the \'Leads\' section.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:833,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;11&quot;:4,&quot;12&quot;:0}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;2. Select the job you want to cancel.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;3. You will find a cancel button to \'Cancel\' the job.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;4. Select the reason for cancellation of the job and submit it.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;5. Your job will be cancelled.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\">5. Your job will be cancelled.</span></span></span></span></span></li>\r\n</ol>\r\n<p><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;1. Visit the \'Leads\' section.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:833,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;11&quot;:4,&quot;12&quot;:0}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;2. Select the job you want to cancel.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;3. You will find a cancel button to \'Cancel\' the job.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;4. Select the reason for cancellation of the job and submit it.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;5. Your job will be cancelled.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;Note:- No Charge if you cancel until 2 hours before the service \\nAfter that, a cancellation fee of Rs 50 will apply.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\">Note:- No Charge if you cancel until 2 hours before the service <br />After that, a cancellation fee of Rs 50 will apply.</span></span></span></span></span></span></p>', '', NULL, '1', 55, '2022-01-08 01:22:21', 55, '2022-01-08 12:22:22'),
(22, NULL, NULL, 'How can I cancel my lead?', '<ol>\r\n<li><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;1. Visit the \'Leads\' section.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:833,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;11&quot;:4,&quot;12&quot;:0}\">Visit the \'Leads\' section.</span></li>\r\n<li><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;1. Visit the \'Leads\' section.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:833,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;11&quot;:4,&quot;12&quot;:0}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;2. Select the job you want to cancel.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\">2. Select the job you want to cancel.</span></span></li>\r\n<li><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;1. Visit the \'Leads\' section.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:833,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;11&quot;:4,&quot;12&quot;:0}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;2. Select the job you want to cancel.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;3. You will find a cancel button to \'Cancel\' the job.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\">3. You will find a cancel button to \'Cancel\' the job.</span></span></span></li>\r\n<li><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;1. Visit the \'Leads\' section.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:833,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;11&quot;:4,&quot;12&quot;:0}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;2. Select the job you want to cancel.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;3. You will find a cancel button to \'Cancel\' the job.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;4. Select the reason for cancellation of the job and submit it.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\">4. Select the reason for cancellation of the job and submit it.</span></span></span></span></li>\r\n<li><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;1. Visit the \'Leads\' section.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:833,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;11&quot;:4,&quot;12&quot;:0}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;2. Select the job you want to cancel.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;3. You will find a cancel button to \'Cancel\' the job.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;4. Select the reason for cancellation of the job and submit it.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;5. Your job will be cancelled.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\">5. Your job will be cancelled.</span></span></span></span></span></li>\r\n</ol>\r\n<p><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;1. Visit the \'Leads\' section.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:833,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;11&quot;:4,&quot;12&quot;:0}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;2. Select the job you want to cancel.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;3. You will find a cancel button to \'Cancel\' the job.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;4. Select the reason for cancellation of the job and submit it.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;5. Your job will be cancelled.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\"><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;Note:- No Charge if you cancel until 2 hours before the service \\nAfter that, a cancellation fee of Rs 50 will apply.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:15297,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;10&quot;:2,&quot;11&quot;:4,&quot;12&quot;:0,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Calibri, sans-serif&quot;,&quot;16&quot;:11}\">Note:- No Charge if you cancel until 2 hours before the service <br />After that, a cancellation fee of Rs 50 will apply.</span></span></span></span></span></span></p>', '', NULL, '1', 55, '2022-01-08 01:22:45', 55, '2022-01-08 12:22:46'),
(23, NULL, NULL, 'How can I cancel my lead?', '<p><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;1. Visit the \'Leads\' section.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:833,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;11&quot;:4,&quot;12&quot;:0}\">Visit the \'Leads\' section.</span></p>', '', NULL, '1', 55, '2022-01-08 01:23:30', 55, '2022-01-08 12:23:31'),
(24, NULL, NULL, 'How can I cancel my lead?', '<p><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;1. Visit the \'Leads\' section.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:833,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;11&quot;:4,&quot;12&quot;:0}\">Visit the \'Leads\' section.</span></p>', '', NULL, '1', 55, '2022-01-08 01:24:11', 55, '2022-01-08 12:24:12'),
(25, NULL, NULL, 'How can I cancel my lead?', '<p><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;1. Visit the \'Leads\' section.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:833,&quot;3&quot;:{&quot;1&quot;:0},&quot;9&quot;:0,&quot;11&quot;:4,&quot;12&quot;:0}\">Visit the \'Leads\' section.</span></p>', '', NULL, '1', 55, '2022-01-08 01:24:46', 55, '2022-01-08 12:24:47'),
(26, NULL, NULL, 'Failed', '<p>ss</p>', '', NULL, '1', 54, '2022-01-08 01:25:41', 54, '2022-01-08 12:25:42'),
(27, NULL, 1, 'How to Reschedule your booking ?', '<p>1. Visit the booking section.<br />2. Select the booking you want to Reschedule.<br />3. Click on the &lsquo;Reschedule&rsquo;.<br />4. Select the new Date and Time slot.<br />5. Your booking is done.</p>', '', 3, '1', 54, '2022-01-08 01:34:19', 55, '2022-01-13 11:07:02'),
(28, NULL, 1, 'How to know if my booking is confirmed or not ?', '<p><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;As soon as you book your service, you will get a confirmation message. &quot;}\" data-sheets-userformat=\"{&quot;2&quot;:14845,&quot;3&quot;:{&quot;1&quot;:0,&quot;3&quot;:1},&quot;5&quot;:{&quot;1&quot;:[{&quot;1&quot;:2,&quot;2&quot;:0,&quot;5&quot;:{&quot;1&quot;:2,&quot;2&quot;:0}},{&quot;1&quot;:0,&quot;2&quot;:0,&quot;3&quot;:3},{&quot;1&quot;:1,&quot;2&quot;:0,&quot;4&quot;:1}]},&quot;6&quot;:{&quot;1&quot;:[{&quot;1&quot;:2,&quot;2&quot;:0,&quot;5&quot;:{&quot;1&quot;:2,&quot;2&quot;:0}},{&quot;1&quot;:0,&quot;2&quot;:0,&quot;3&quot;:3},{&quot;1&quot;:1,&quot;2&quot;:0,&quot;4&quot;:1}]},&quot;7&quot;:{&quot;1&quot;:[{&quot;1&quot;:2,&quot;2&quot;:0,&quot;5&quot;:{&quot;1&quot;:2,&quot;2&quot;:0}},{&quot;1&quot;:0,&quot;2&quot;:0,&quot;3&quot;:3},{&quot;1&quot;:1,&quot;2&quot;:0,&quot;4&quot;:1}]},&quot;8&quot;:{&quot;1&quot;:[{&quot;1&quot;:2,&quot;2&quot;:0,&quot;5&quot;:{&quot;1&quot;:2,&quot;2&quot;:0}},{&quot;1&quot;:0,&quot;2&quot;:0,&quot;3&quot;:3},{&quot;1&quot;:1,&quot;2&quot;:0,&quot;4&quot;:1}]},&quot;9&quot;:0,&quot;10&quot;:1,&quot;11&quot;:4,&quot;14&quot;:{&quot;1&quot;:3,&quot;3&quot;:1},&quot;15&quot;:&quot;Calibri&quot;,&quot;16&quot;:11}\">As soon as you book your service, you will get a confirmation message. </span></p>', '', 4, '1', 54, '2022-01-08 01:35:25', 55, '2022-01-13 11:07:25'),
(29, NULL, 1, 'How can I contact the Expert ?', '<p>1. Visit the Booking section.<br />2. Select the booking for which you want to contact the Expert.<br />3. Here you will get the contact details of the Expert.<br />4. You will be able to contact the Expert before \"2\" hours of scheduled timing.</p>', '', 5, '1', 54, '2022-01-08 01:36:50', 55, '2022-01-13 15:33:26');
INSERT INTO `help_question_answers` (`id`, `parent_id`, `help_menu_id`, `question`, `answer`, `clikable_slug`, `display_order_no`, `status`, `created_by`, `created`, `modified_by`, `modified`) VALUES
(30, NULL, 3, 'How can I cancel my lead?', '<ol>\r\n<li><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" visit=\"\" the=\"\" leads=\"\" section=\"\" data-sheets-userformat=\"{\" :833=\"\" 3=\"\" :0=\"\" 9=\"\" 11=\"\" :4=\"\" 12=\"\">Visit the \'Leads\' section.</span></li>\r\n<li><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" visit=\"\" the=\"\" leads=\"\" section=\"\" data-sheets-userformat=\"{\" :833=\"\" 3=\"\" :0=\"\" 9=\"\" 11=\"\" :4=\"\" 12=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" select=\"\" the=\"\" job=\"\" you=\"\" want=\"\" to=\"\" cancel=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\">Select the job you want to cancel.</span></span></li>\r\n<li><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" visit=\"\" the=\"\" leads=\"\" section=\"\" data-sheets-userformat=\"{\" :833=\"\" 3=\"\" :0=\"\" 9=\"\" 11=\"\" :4=\"\" 12=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" select=\"\" the=\"\" job=\"\" you=\"\" want=\"\" to=\"\" cancel=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 3=\"\" you=\"\" will=\"\" find=\"\" a=\"\" cancel=\"\" button=\"\" to=\"\" the=\"\" job=\"\" data-sheets-userformat=\"{\" :15297=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\">You will find a cancel button to \'Cancel\' the job.</span></span></span></li>\r\n<li><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" visit=\"\" the=\"\" leads=\"\" section=\"\" data-sheets-userformat=\"{\" :833=\"\" 3=\"\" :0=\"\" 9=\"\" 11=\"\" :4=\"\" 12=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" select=\"\" the=\"\" job=\"\" you=\"\" want=\"\" to=\"\" cancel=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 3=\"\" you=\"\" will=\"\" find=\"\" a=\"\" cancel=\"\" button=\"\" to=\"\" the=\"\" job=\"\" data-sheets-userformat=\"{\" :15297=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 4=\"\" select=\"\" the=\"\" reason=\"\" for=\"\" cancellation=\"\" of=\"\" job=\"\" and=\"\" submit=\"\" it=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\">Select the reason for the cancellation of the job and submit it.</span></span></span></span></li>\r\n<li><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" visit=\"\" the=\"\" leads=\"\" section=\"\" data-sheets-userformat=\"{\" :833=\"\" 3=\"\" :0=\"\" 9=\"\" 11=\"\" :4=\"\" 12=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" select=\"\" the=\"\" job=\"\" you=\"\" want=\"\" to=\"\" cancel=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 3=\"\" you=\"\" will=\"\" find=\"\" a=\"\" cancel=\"\" button=\"\" to=\"\" the=\"\" job=\"\" data-sheets-userformat=\"{\" :15297=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 4=\"\" select=\"\" the=\"\" reason=\"\" for=\"\" cancellation=\"\" of=\"\" job=\"\" and=\"\" submit=\"\" it=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 5=\"\" your=\"\" job=\"\" will=\"\" be=\"\" cancelled=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\">Your job will be canceled.</span></span></span></span></span></li>\r\n</ol>\r\n<p><strong>Note:-</strong> There will be no penalty if you cancel the lead before 2 hours of the booking time, after that the cancelation fee will be applicable.</p>', '1', 2, '1', 55, '2022-01-08 02:16:44', 55, '2022-01-12 17:18:21'),
(31, NULL, 3, 'How can I change my service area?', '<ul>\r\n<li><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" to=\"\" change=\"\" the=\"\" service=\"\" area=\"\" you=\"\" have=\"\" contact=\"\" your=\"\" catagory=\"\" manager=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\">To change the service Area you have to contact your <em><strong>Catagory Manager</strong></em>.</span></li>\r\n</ul>', '', 3, '1', 55, '2022-01-08 02:21:34', 55, '2022-01-12 17:20:21'),
(32, NULL, 3, 'Why I am getting leads out of my working Area?', '<ul>\r\n<li>The lead is distributed in a fixed area around the customer, it might possible that your working area comes under the distribution area (<em>for further information contact your supporting manager</em>).</li>\r\n</ul>', '', 4, '1', 55, '2022-01-08 02:23:10', 55, '2022-01-12 17:39:19'),
(33, NULL, 5, 'How can I recharge my credit points ?', '<ol>\r\n<li><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" visit=\"\" the=\"\" profile=\"\" section=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\">Visit the \'Profile\' section.</span></li>\r\n<li><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" visit=\"\" the=\"\" profile=\"\" section=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" open=\"\" the=\"\" page=\"\" credit=\"\" balance=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\">Open the page \'Credit Balance\'.</span></span></li>\r\n<li><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" visit=\"\" the=\"\" profile=\"\" section=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" open=\"\" the=\"\" page=\"\" credit=\"\" balance=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 3=\"\" here=\"\" you=\"\" can=\"\" see=\"\" your=\"\" current=\"\" credits=\"\" and=\"\" a=\"\" button=\"\" buy=\"\" credit=\"\" data-sheets-userformat=\"{\" :15297=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\">Here you can see your current Credits and a button \'Buy Credit\'.</span></span></span></li>\r\n<li><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" visit=\"\" the=\"\" profile=\"\" section=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" open=\"\" the=\"\" page=\"\" credit=\"\" balance=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 3=\"\" here=\"\" you=\"\" can=\"\" see=\"\" your=\"\" current=\"\" credits=\"\" and=\"\" a=\"\" button=\"\" buy=\"\" credit=\"\" data-sheets-userformat=\"{\" :15297=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 4=\"\" select=\"\" the=\"\" amount=\"\" of=\"\" credit=\"\" you=\"\" want=\"\" to=\"\" recharge=\"\" data-sheets-userformat=\"{\" :15171=\"\" 3=\"\" :0=\"\" :16777215=\"\" 9=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" docs-calibri=\"\" 16=\"\" :11=\"\">Select the amount of the credit you want to recharge.</span></span></span></span></li>\r\n<li><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" visit=\"\" the=\"\" profile=\"\" section=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" open=\"\" the=\"\" page=\"\" credit=\"\" balance=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 3=\"\" here=\"\" you=\"\" can=\"\" see=\"\" your=\"\" current=\"\" credits=\"\" and=\"\" a=\"\" button=\"\" buy=\"\" credit=\"\" data-sheets-userformat=\"{\" :15297=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 4=\"\" select=\"\" the=\"\" amount=\"\" of=\"\" credit=\"\" you=\"\" want=\"\" to=\"\" recharge=\"\" data-sheets-userformat=\"{\" :15171=\"\" 3=\"\" :0=\"\" :16777215=\"\" 9=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" docs-calibri=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 5=\"\" enter=\"\" mobile=\"\" number=\"\" and=\"\" mail=\"\" id=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\">Enter Mobile number and Mail ID.</span></span></span></span></span></li>\r\n<li><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" visit=\"\" the=\"\" profile=\"\" section=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" open=\"\" the=\"\" page=\"\" credit=\"\" balance=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 3=\"\" here=\"\" you=\"\" can=\"\" see=\"\" your=\"\" current=\"\" credits=\"\" and=\"\" a=\"\" button=\"\" buy=\"\" credit=\"\" data-sheets-userformat=\"{\" :15297=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 4=\"\" select=\"\" the=\"\" amount=\"\" of=\"\" credit=\"\" you=\"\" want=\"\" to=\"\" recharge=\"\" data-sheets-userformat=\"{\" :15171=\"\" 3=\"\" :0=\"\" :16777215=\"\" 9=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" docs-calibri=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 5=\"\" enter=\"\" mobile=\"\" number=\"\" and=\"\" mail=\"\" id=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 6=\"\" select=\"\" the=\"\" payment=\"\" method=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\">Select the payment method.</span></span></span></span></span></span></li>\r\n<li><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" visit=\"\" the=\"\" profile=\"\" section=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" open=\"\" the=\"\" page=\"\" credit=\"\" balance=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 3=\"\" here=\"\" you=\"\" can=\"\" see=\"\" your=\"\" current=\"\" credits=\"\" and=\"\" a=\"\" button=\"\" buy=\"\" credit=\"\" data-sheets-userformat=\"{\" :15297=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 4=\"\" select=\"\" the=\"\" amount=\"\" of=\"\" credit=\"\" you=\"\" want=\"\" to=\"\" recharge=\"\" data-sheets-userformat=\"{\" :15171=\"\" 3=\"\" :0=\"\" :16777215=\"\" 9=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" docs-calibri=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 5=\"\" enter=\"\" mobile=\"\" number=\"\" and=\"\" mail=\"\" id=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 6=\"\" select=\"\" the=\"\" payment=\"\" method=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 7=\"\" your=\"\" recharge=\"\" is=\"\" completed=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\">Your recharge is completed.</span></span></span></span></span></span></span></li>\r\n</ol>\r\n<p><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" visit=\"\" the=\"\" profile=\"\" section=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" open=\"\" the=\"\" page=\"\" credit=\"\" balance=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 3=\"\" here=\"\" you=\"\" can=\"\" see=\"\" your=\"\" current=\"\" credits=\"\" and=\"\" a=\"\" button=\"\" buy=\"\" credit=\"\" data-sheets-userformat=\"{\" :15297=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 4=\"\" select=\"\" the=\"\" amount=\"\" of=\"\" credit=\"\" you=\"\" want=\"\" to=\"\" recharge=\"\" data-sheets-userformat=\"{\" :15171=\"\" 3=\"\" :0=\"\" :16777215=\"\" 9=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" docs-calibri=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 5=\"\" enter=\"\" mobile=\"\" number=\"\" and=\"\" mail=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 6=\"\" select=\"\" the=\"\" payment=\"\" method=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 7=\"\" your=\"\" recharge=\"\" is=\"\" completed=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\">&nbsp; &nbsp; &nbsp; OR</span></span></span></span></span></span></span></p>\r\n<ol>\r\n<li><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" visit=\"\" the=\"\" profile=\"\" section=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" open=\"\" the=\"\" page=\"\" credit=\"\" balance=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 3=\"\" here=\"\" you=\"\" can=\"\" see=\"\" your=\"\" current=\"\" credits=\"\" and=\"\" a=\"\" button=\"\" buy=\"\" credit=\"\" data-sheets-userformat=\"{\" :15297=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 4=\"\" select=\"\" the=\"\" amount=\"\" of=\"\" credit=\"\" you=\"\" want=\"\" to=\"\" recharge=\"\" data-sheets-userformat=\"{\" :15171=\"\" 3=\"\" :0=\"\" :16777215=\"\" 9=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" docs-calibri=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 5=\"\" enter=\"\" mobile=\"\" number=\"\" and=\"\" mail=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 6=\"\" select=\"\" the=\"\" payment=\"\" method=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 7=\"\" your=\"\" recharge=\"\" is=\"\" completed=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\">Visit the \'Money\' page.</span></span></span></span></span></span></span></li>\r\n<li><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" visit=\"\" the=\"\" profile=\"\" section=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" open=\"\" the=\"\" page=\"\" credit=\"\" balance=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 3=\"\" here=\"\" you=\"\" can=\"\" see=\"\" your=\"\" current=\"\" credits=\"\" and=\"\" a=\"\" button=\"\" buy=\"\" credit=\"\" data-sheets-userformat=\"{\" :15297=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 4=\"\" select=\"\" the=\"\" amount=\"\" of=\"\" credit=\"\" you=\"\" want=\"\" to=\"\" recharge=\"\" data-sheets-userformat=\"{\" :15171=\"\" 3=\"\" :0=\"\" :16777215=\"\" 9=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" docs-calibri=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 5=\"\" enter=\"\" mobile=\"\" number=\"\" and=\"\" mail=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 6=\"\" select=\"\" the=\"\" payment=\"\" method=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 7=\"\" your=\"\" recharge=\"\" is=\"\" completed=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\">Go to the \'Recharge\' button.</span></span></span></span></span></span></span></li>\r\n<li><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" visit=\"\" the=\"\" profile=\"\" section=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" open=\"\" the=\"\" page=\"\" credit=\"\" balance=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 3=\"\" here=\"\" you=\"\" can=\"\" see=\"\" your=\"\" current=\"\" credits=\"\" and=\"\" a=\"\" button=\"\" buy=\"\" credit=\"\" data-sheets-userformat=\"{\" :15297=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 4=\"\" select=\"\" the=\"\" amount=\"\" of=\"\" credit=\"\" you=\"\" want=\"\" to=\"\" recharge=\"\" data-sheets-userformat=\"{\" :15171=\"\" 3=\"\" :0=\"\" :16777215=\"\" 9=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" docs-calibri=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 5=\"\" enter=\"\" mobile=\"\" number=\"\" and=\"\" mail=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 6=\"\" select=\"\" the=\"\" payment=\"\" method=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 7=\"\" your=\"\" recharge=\"\" is=\"\" completed=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\">Select the option for recharge.</span></span></span></span></span></span></span></li>\r\n<li><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" visit=\"\" the=\"\" profile=\"\" section=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" open=\"\" the=\"\" page=\"\" credit=\"\" balance=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 3=\"\" here=\"\" you=\"\" can=\"\" see=\"\" your=\"\" current=\"\" credits=\"\" and=\"\" a=\"\" button=\"\" buy=\"\" credit=\"\" data-sheets-userformat=\"{\" :15297=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 4=\"\" select=\"\" the=\"\" amount=\"\" of=\"\" credit=\"\" you=\"\" want=\"\" to=\"\" recharge=\"\" data-sheets-userformat=\"{\" :15171=\"\" 3=\"\" :0=\"\" :16777215=\"\" 9=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" docs-calibri=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 5=\"\" enter=\"\" mobile=\"\" number=\"\" and=\"\" mail=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 6=\"\" select=\"\" the=\"\" payment=\"\" method=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 7=\"\" your=\"\" recharge=\"\" is=\"\" completed=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\">Complete the payment procedure</span></span></span></span></span></span></span></li>\r\n<li><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" visit=\"\" the=\"\" profile=\"\" section=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" open=\"\" the=\"\" page=\"\" credit=\"\" balance=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 3=\"\" here=\"\" you=\"\" can=\"\" see=\"\" your=\"\" current=\"\" credits=\"\" and=\"\" a=\"\" button=\"\" buy=\"\" credit=\"\" data-sheets-userformat=\"{\" :15297=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 4=\"\" select=\"\" the=\"\" amount=\"\" of=\"\" credit=\"\" you=\"\" want=\"\" to=\"\" recharge=\"\" data-sheets-userformat=\"{\" :15171=\"\" 3=\"\" :0=\"\" :16777215=\"\" 9=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" docs-calibri=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 5=\"\" enter=\"\" mobile=\"\" number=\"\" and=\"\" mail=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 6=\"\" select=\"\" the=\"\" payment=\"\" method=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 7=\"\" your=\"\" recharge=\"\" is=\"\" completed=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\">Fill in Mobile Number and Email ID.</span></span></span></span></span></span></span></li>\r\n<li><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" visit=\"\" the=\"\" profile=\"\" section=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" open=\"\" the=\"\" page=\"\" credit=\"\" balance=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 3=\"\" here=\"\" you=\"\" can=\"\" see=\"\" your=\"\" current=\"\" credits=\"\" and=\"\" a=\"\" button=\"\" buy=\"\" credit=\"\" data-sheets-userformat=\"{\" :15297=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 4=\"\" select=\"\" the=\"\" amount=\"\" of=\"\" credit=\"\" you=\"\" want=\"\" to=\"\" recharge=\"\" data-sheets-userformat=\"{\" :15171=\"\" 3=\"\" :0=\"\" :16777215=\"\" 9=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" docs-calibri=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 5=\"\" enter=\"\" mobile=\"\" number=\"\" and=\"\" mail=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 6=\"\" select=\"\" the=\"\" payment=\"\" method=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 7=\"\" your=\"\" recharge=\"\" is=\"\" completed=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\">Select payment method.</span></span></span></span></span></span></span></li>\r\n<li><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" visit=\"\" the=\"\" profile=\"\" section=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" open=\"\" the=\"\" page=\"\" credit=\"\" balance=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 3=\"\" here=\"\" you=\"\" can=\"\" see=\"\" your=\"\" current=\"\" credits=\"\" and=\"\" a=\"\" button=\"\" buy=\"\" credit=\"\" data-sheets-userformat=\"{\" :15297=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 4=\"\" select=\"\" the=\"\" amount=\"\" of=\"\" credit=\"\" you=\"\" want=\"\" to=\"\" recharge=\"\" data-sheets-userformat=\"{\" :15171=\"\" 3=\"\" :0=\"\" :16777215=\"\" 9=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" docs-calibri=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 5=\"\" enter=\"\" mobile=\"\" number=\"\" and=\"\" mail=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 6=\"\" select=\"\" the=\"\" payment=\"\" method=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\"><span data-sheets-value=\"{\" 1=\"\" :2=\"\" 2=\"\" :=\"\" 7=\"\" your=\"\" recharge=\"\" is=\"\" completed=\"\" data-sheets-userformat=\"{\" :15297=\"\" 3=\"\" :0=\"\" 9=\"\" 10=\"\" 11=\"\" :4=\"\" 12=\"\" 14=\"\" 15=\"\" calibri=\"\" sans-serif=\"\" 16=\"\" :11=\"\">Your recharge is completed </span></span></span></span></span></span></span></li>\r\n</ol>', '', 1, '1', 55, '2022-01-08 02:27:09', 55, '2022-01-12 17:35:47'),
(35, NULL, 1, 'How can I rate and review the service ?', '<p>As soon as the service will be completed, you will get a feedback form where you can rate and review the service.</p>', '', 6, '1', 55, '2022-01-10 07:10:44', 55, '2022-01-13 11:08:18'),
(36, NULL, 3, 'How to use wallet amount? ll', '<p>fajajjajqafhhuaerhnhrsehhsd</p>', '', 1, '0', 55, '2022-01-10 07:11:34', 55, '2022-01-10 18:12:28'),
(37, 7, 7, 'How can I order the products for the service?', '<p>1. Visit the \'Shop\' section.<br />2. Select the products you want to purchase and proceed.<br />3. Fill the Address detail.<br />4. Finish the payment procedure.<br />5. And your Order Placed.</p>', '', 1, '1', 55, '2022-01-12 06:24:42', 55, '2022-01-12 17:24:42'),
(38, 7, 7, 'Can I use referral points to purchase products?', '<ul>\r\n<li>No, you can\'t use your referral point to purchase any products. The referral points will automatically credit to your Credit Balance.</li>\r\n</ul>', '', 1, '1', 55, '2022-01-12 06:28:25', 55, '2022-01-12 17:28:25'),
(39, NULL, 9, 'How can I deactivate my account ?', '<ul>\r\n<li>To deactivate the account you have to contact to your Category manager.</li>\r\n</ul>', '', 1, '1', 55, '2022-01-12 06:29:26', 55, '2022-01-12 17:30:16'),
(40, 9, 9, 'How can I change service Area ?', '<ul>\r\n<li><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;For changing the service area please contact your Category manager.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:14781,&quot;3&quot;:{&quot;1&quot;:0,&quot;3&quot;:1},&quot;5&quot;:{&quot;1&quot;:[{&quot;1&quot;:2,&quot;2&quot;:0,&quot;5&quot;:{&quot;1&quot;:2,&quot;2&quot;:0}},{&quot;1&quot;:0,&quot;2&quot;:0,&quot;3&quot;:3},{&quot;1&quot;:1,&quot;2&quot;:0,&quot;4&quot;:1}]},&quot;6&quot;:{&quot;1&quot;:[{&quot;1&quot;:2,&quot;2&quot;:0,&quot;5&quot;:{&quot;1&quot;:2,&quot;2&quot;:0}},{&quot;1&quot;:0,&quot;2&quot;:0,&quot;3&quot;:3},{&quot;1&quot;:1,&quot;2&quot;:0,&quot;4&quot;:1}]},&quot;7&quot;:{&quot;1&quot;:[{&quot;1&quot;:2,&quot;2&quot;:0,&quot;5&quot;:{&quot;1&quot;:2,&quot;2&quot;:0}},{&quot;1&quot;:0,&quot;2&quot;:0,&quot;3&quot;:3},{&quot;1&quot;:1,&quot;2&quot;:0,&quot;4&quot;:1}]},&quot;8&quot;:{&quot;1&quot;:[{&quot;1&quot;:2,&quot;2&quot;:0,&quot;5&quot;:{&quot;1&quot;:2,&quot;2&quot;:0}},{&quot;1&quot;:0,&quot;2&quot;:0,&quot;3&quot;:3},{&quot;1&quot;:1,&quot;2&quot;:0,&quot;4&quot;:1}]},&quot;10&quot;:1,&quot;11&quot;:4,&quot;14&quot;:{&quot;1&quot;:3,&quot;3&quot;:1},&quot;15&quot;:&quot;Calibri&quot;,&quot;16&quot;:11}\">For changing the service area please contact your Category manager.</span></li>\r\n</ul>', '', 2, '1', 55, '2022-01-12 06:29:49', 55, '2022-01-12 17:29:49'),
(41, 9, 9, 'How can I change my service Category ?', '<ul>\r\n<li><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;To change your service Category you have to contact your Category manager.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:14781,&quot;3&quot;:{&quot;1&quot;:0,&quot;3&quot;:1},&quot;5&quot;:{&quot;1&quot;:[{&quot;1&quot;:2,&quot;2&quot;:0,&quot;5&quot;:{&quot;1&quot;:2,&quot;2&quot;:0}},{&quot;1&quot;:0,&quot;2&quot;:0,&quot;3&quot;:3},{&quot;1&quot;:1,&quot;2&quot;:0,&quot;4&quot;:1}]},&quot;6&quot;:{&quot;1&quot;:[{&quot;1&quot;:2,&quot;2&quot;:0,&quot;5&quot;:{&quot;1&quot;:2,&quot;2&quot;:0}},{&quot;1&quot;:0,&quot;2&quot;:0,&quot;3&quot;:3},{&quot;1&quot;:1,&quot;2&quot;:0,&quot;4&quot;:1}]},&quot;7&quot;:{&quot;1&quot;:[{&quot;1&quot;:2,&quot;2&quot;:0,&quot;5&quot;:{&quot;1&quot;:2,&quot;2&quot;:0}},{&quot;1&quot;:0,&quot;2&quot;:0,&quot;3&quot;:3},{&quot;1&quot;:1,&quot;2&quot;:0,&quot;4&quot;:1}]},&quot;8&quot;:{&quot;1&quot;:[{&quot;1&quot;:2,&quot;2&quot;:0,&quot;5&quot;:{&quot;1&quot;:2,&quot;2&quot;:0}},{&quot;1&quot;:0,&quot;2&quot;:0,&quot;3&quot;:3},{&quot;1&quot;:1,&quot;2&quot;:0,&quot;4&quot;:1}]},&quot;10&quot;:1,&quot;11&quot;:4,&quot;14&quot;:{&quot;1&quot;:3,&quot;3&quot;:1},&quot;15&quot;:&quot;Calibri&quot;,&quot;16&quot;:11}\">To change your service Category you have to contact your Category manager.</span></li>\r\n</ul>', '', 3, '1', 55, '2022-01-12 06:30:07', 55, '2022-01-12 17:30:07'),
(42, 11, 11, 'How can I contact to suppot team ?', '<p>1. Visit \'Profile\'.<br />2. In the \'Other\' section you will find the \'Contact Us\' option.<br />3. Here you can register your queries.</p>\r\n<p><br /><strong>Note:-</strong> The support team will contact you soon.</p>', '', 1, '1', 55, '2022-01-12 06:32:16', 55, '2022-01-12 17:32:16'),
(43, NULL, 11, 'How can I apply for a leave ?', '<p>1. On the \'New\' page visit \'Booking Calendar\'.<br />2. Select the \'Date\'.<br />3. Select the time slot <em>or</em> full-day leave.<br />4. Confirm your leave.<br />5. Category Manager will approve and reject your request.</p>', '', 2, '1', 55, '2022-01-12 06:32:37', 55, '2022-01-12 17:40:52'),
(44, 5, 5, 'What are Referral Points ?', '<ul>\r\n<li><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;When you refer the app to somebody and he/she join us as a partner and complete their first job, after that you are eligible for the points that are \'Referral Points\'.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:14781,&quot;3&quot;:{&quot;1&quot;:0,&quot;3&quot;:1},&quot;5&quot;:{&quot;1&quot;:[{&quot;1&quot;:2,&quot;2&quot;:0,&quot;5&quot;:{&quot;1&quot;:2,&quot;2&quot;:0}},{&quot;1&quot;:0,&quot;2&quot;:0,&quot;3&quot;:3},{&quot;1&quot;:1,&quot;2&quot;:0,&quot;4&quot;:1}]},&quot;6&quot;:{&quot;1&quot;:[{&quot;1&quot;:2,&quot;2&quot;:0,&quot;5&quot;:{&quot;1&quot;:2,&quot;2&quot;:0}},{&quot;1&quot;:0,&quot;2&quot;:0,&quot;3&quot;:3},{&quot;1&quot;:1,&quot;2&quot;:0,&quot;4&quot;:1}]},&quot;7&quot;:{&quot;1&quot;:[{&quot;1&quot;:2,&quot;2&quot;:0,&quot;5&quot;:{&quot;1&quot;:2,&quot;2&quot;:0}},{&quot;1&quot;:0,&quot;2&quot;:0,&quot;3&quot;:3},{&quot;1&quot;:1,&quot;2&quot;:0,&quot;4&quot;:1}]},&quot;8&quot;:{&quot;1&quot;:[{&quot;1&quot;:2,&quot;2&quot;:0,&quot;5&quot;:{&quot;1&quot;:2,&quot;2&quot;:0}},{&quot;1&quot;:0,&quot;2&quot;:0,&quot;3&quot;:3},{&quot;1&quot;:1,&quot;2&quot;:0,&quot;4&quot;:1}]},&quot;10&quot;:1,&quot;11&quot;:4,&quot;14&quot;:{&quot;1&quot;:3,&quot;3&quot;:1},&quot;15&quot;:&quot;Calibri&quot;,&quot;16&quot;:11}\">When you refer the app to somebody and he/she join us as a partner and complete their first job, after that you are eligible for the points that are \'Referral Points\'.</span></li>\r\n</ul>', '', 2, '1', 55, '2022-01-12 06:36:20', 55, '2022-01-12 17:36:20'),
(45, 5, 5, 'How can I use \'Referral Points\' ?', '<ul>\r\n<li><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;Referral Points can be used to book leads. As you earn these points, it will credit in your \'Credit Balance\'.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:769,&quot;3&quot;:{&quot;1&quot;:0},&quot;11&quot;:4,&quot;12&quot;:0}\">Referral Points can be used to book leads. As you earn these points, it will credit in your \'Credit Balance\'.</span></li>\r\n</ul>', '', 3, '1', 55, '2022-01-12 06:36:58', 55, '2022-01-12 17:36:58'),
(46, 5, 5, 'Can I use referral points to purchase products ?', '<ul>\r\n<li><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;No, you can\'t use your referral point to purchase any products. They can only be use as Credit Balance.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:14781,&quot;3&quot;:{&quot;1&quot;:0,&quot;3&quot;:1},&quot;5&quot;:{&quot;1&quot;:[{&quot;1&quot;:2,&quot;2&quot;:0,&quot;5&quot;:{&quot;1&quot;:2,&quot;2&quot;:0}},{&quot;1&quot;:0,&quot;2&quot;:0,&quot;3&quot;:3},{&quot;1&quot;:1,&quot;2&quot;:0,&quot;4&quot;:1}]},&quot;6&quot;:{&quot;1&quot;:[{&quot;1&quot;:2,&quot;2&quot;:0,&quot;5&quot;:{&quot;1&quot;:2,&quot;2&quot;:0}},{&quot;1&quot;:0,&quot;2&quot;:0,&quot;3&quot;:3},{&quot;1&quot;:1,&quot;2&quot;:0,&quot;4&quot;:1}]},&quot;7&quot;:{&quot;1&quot;:[{&quot;1&quot;:2,&quot;2&quot;:0,&quot;5&quot;:{&quot;1&quot;:2,&quot;2&quot;:0}},{&quot;1&quot;:0,&quot;2&quot;:0,&quot;3&quot;:3},{&quot;1&quot;:1,&quot;2&quot;:0,&quot;4&quot;:1}]},&quot;8&quot;:{&quot;1&quot;:[{&quot;1&quot;:2,&quot;2&quot;:0,&quot;5&quot;:{&quot;1&quot;:2,&quot;2&quot;:0}},{&quot;1&quot;:0,&quot;2&quot;:0,&quot;3&quot;:3},{&quot;1&quot;:1,&quot;2&quot;:0,&quot;4&quot;:1}]},&quot;10&quot;:1,&quot;11&quot;:4,&quot;14&quot;:{&quot;1&quot;:3,&quot;3&quot;:1},&quot;15&quot;:&quot;Calibri&quot;,&quot;16&quot;:11}\">No, you can\'t use your referral point to purchase any products. They can only be used as Credit Balance.</span></li>\r\n</ul>', '', 4, '1', 55, '2022-01-12 06:37:21', 55, '2022-01-12 17:37:21'),
(47, NULL, 2, 'How to pay for the service ?', '<p>We accept</p>\r\n<p>1. UPI payment</p>\r\n<p>2. Net banking</p>\r\n<p>3. Debit or credit card payment</p>\r\n<p>4. Online wallets (Paytm, Amazon Pay, etc.)</p>\r\n<p>5. Cash</p>\r\n<p><strong>Note:-</strong> You can pay at the time of booking or after the service.<br /><br /></p>', '', 1, '1', 55, '2022-01-13 00:09:38', 55, '2022-01-21 09:58:52'),
(48, 2, 2, 'How to use Referral points ?', '<p><span data-sheets-value=\"{&quot;1&quot;:2,&quot;2&quot;:&quot;On the Checkout page, you will find the option \'Use Referral Points\', you can select the option and use your points. The amount will be deducted from the final bill.&quot;}\" data-sheets-userformat=\"{&quot;2&quot;:14719,&quot;3&quot;:{&quot;1&quot;:0,&quot;3&quot;:1},&quot;4&quot;:{&quot;1&quot;:2,&quot;2&quot;:16777215},&quot;5&quot;:{&quot;1&quot;:[{&quot;1&quot;:2,&quot;2&quot;:0,&quot;5&quot;:{&quot;1&quot;:2,&quot;2&quot;:0}},{&quot;1&quot;:0,&quot;2&quot;:0,&quot;3&quot;:3},{&quot;1&quot;:1,&quot;2&quot;:0,&quot;4&quot;:1}]},&quot;6&quot;:{&quot;1&quot;:[{&quot;1&quot;:2,&quot;2&quot;:0,&quot;5&quot;:{&quot;1&quot;:2,&quot;2&quot;:0}},{&quot;1&quot;:0,&quot;2&quot;:0,&quot;3&quot;:3},{&quot;1&quot;:1,&quot;2&quot;:0,&quot;4&quot;:1}]},&quot;7&quot;:{&quot;1&quot;:[{&quot;1&quot;:2,&quot;2&quot;:0,&quot;5&quot;:{&quot;1&quot;:2,&quot;2&quot;:0}},{&quot;1&quot;:0,&quot;2&quot;:0,&quot;3&quot;:3},{&quot;1&quot;:1,&quot;2&quot;:0,&quot;4&quot;:1}]},&quot;8&quot;:{&quot;1&quot;:[{&quot;1&quot;:2,&quot;2&quot;:0,&quot;5&quot;:{&quot;1&quot;:2,&quot;2&quot;:0}},{&quot;1&quot;:0,&quot;2&quot;:0,&quot;3&quot;:3},{&quot;1&quot;:1,&quot;2&quot;:0,&quot;4&quot;:1}]},&quot;9&quot;:0,&quot;11&quot;:4,&quot;14&quot;:{&quot;1&quot;:2,&quot;2&quot;:0},&quot;15&quot;:&quot;Arial&quot;,&quot;16&quot;:11}\">On the Checkout page, you will find the option \'Use Referral Points\', you can select the option and use your points. The amount will be deducted from the final bill.</span></p>', '', 2, '1', 55, '2022-01-13 00:09:56', 55, '2022-01-13 11:09:56'),
(49, 15, 15, 'How to Get Invoice ?', '<p>1. Go to \'Booking Page\'.<br />2. Select the booking you want the Invoice for. <br />3. You will find the \'Email invoice\' button to get the Invoice on your Email ID.<br />4. Enter the Email ID on which you want the Invoice.</p>', '', 1, '1', 55, '2022-01-13 00:33:18', 55, '2022-01-13 11:33:19'),
(50, 14, 14, 'Covid-19 safety protocol', '<ol>\r\n<li>Safety is our top priority</li>\r\n<li>Fully vaccinated Expert</li>\r\n<li>Covid-19 test in a fixed interval of time</li>\r\n<li>Uses of mask and gloves are mandatory for the Expert</li>\r\n<li>Daily temperature check</li>\r\n<li>Single-use products and disposables</li>\r\n<li>All tools are regularly sanitized</li>\r\n<li>All the WHO norms are followed by the Assisto team</li>\r\n</ol>', '', 1, '1', 55, '2022-01-13 00:37:18', 55, '2022-01-13 11:37:19');

-- --------------------------------------------------------

--
-- Table structure for table `issues`
--

CREATE TABLE `issues` (
  `id` int(11) NOT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `issue_subject_id` int(11) DEFAULT NULL,
  `issue_sub_subject_id` int(11) DEFAULT NULL,
  `user_type` enum('1','2') DEFAULT '1' COMMENT '1 For customer 2 for partner',
  `message` text DEFAULT NULL,
  `message_by` enum('1','0') DEFAULT '0' COMMENT '0 Means customer/partner 1 for admin',
  `parent_id` int(11) DEFAULT NULL COMMENT ' id become issue_id here if the message is going on once after the first message',
  `raise_by` enum('1','2','3') NOT NULL DEFAULT '1' COMMENT '1 For customer\r\n2 For partner\r\n3 For Admin/support',
  `status` enum('0','1','2','3','4','5') NOT NULL DEFAULT '0' COMMENT '0 means open\r\n1 means close by customer\r\n2 means close by admin\r\n3 means reopen by customer\r\n4 means reopen by admin\r\n5 means ignore \r\n',
  `refund` enum('0','1','2','3','4') NOT NULL DEFAULT '0' COMMENT '0 Means not requested\r\n1 Means requested\r\n2 Means Approved\r\n3 Means not approved\r\n4 Means refund Released as coupon',
  `reply_expected` enum('1','0') NOT NULL DEFAULT '0' COMMENT '0 Means No 1 Means Yes',
  `created` timestamp NULL DEFAULT current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `issue_documents`
--

CREATE TABLE `issue_documents` (
  `id` int(11) NOT NULL,
  `issue_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `document` longtext DEFAULT NULL,
  `created` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `issue_sub_reason`
--

CREATE TABLE `issue_sub_reason` (
  `id` int(11) NOT NULL,
  `issue_reason_id` int(11) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `status` enum('1','0') NOT NULL,
  `display_order_no` int(11) NOT NULL DEFAULT 1,
  `created` timestamp NULL DEFAULT current_timestamp(),
  `created_by` int(11) DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  `modified_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `offers`
--

CREATE TABLE `offers` (
  `id` int(11) NOT NULL,
  `top_banner` enum('0','1') NOT NULL DEFAULT '0',
  `best_offer` enum('0','1') NOT NULL DEFAULT '0',
  `image` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `start_from` datetime DEFAULT NULL,
  `end_to` datetime DEFAULT NULL,
  `min_amount` int(11) DEFAULT NULL,
  `max_amount` int(11) DEFAULT NULL,
  `coupon_code` varchar(255) DEFAULT NULL,
  `offer_type` enum('1','2') NOT NULL DEFAULT '1' COMMENT '1 Means %(Percent) 2 means flat',
  `discount_amount` int(11) DEFAULT NULL,
  `coupon_count` int(11) DEFAULT 1,
  `pending_count` int(11) NOT NULL,
  `display_order_no` int(11) NOT NULL,
  `use_per_user` int(11) DEFAULT NULL,
  `visibility` enum('1','0') NOT NULL DEFAULT '1' COMMENT '1 means visible for all 0 means individual coupon for private',
  `use_per_coupon` int(11) DEFAULT NULL,
  `offer_terms_conditions` text NOT NULL,
  `status` enum('1','0') NOT NULL DEFAULT '1' COMMENT '1 Means Active 0 Means not active',
  `created_by` int(11) DEFAULT NULL,
  `created` datetime DEFAULT current_timestamp(),
  `modified_by` int(11) DEFAULT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment_options`
--

CREATE TABLE `payment_options` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `card_number` varchar(255) DEFAULT NULL,
  `card_name` varchar(255) DEFAULT NULL,
  `payment_gateway_id` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT current_timestamp(),
  `modified` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment_pre`
--

CREATE TABLE `payment_pre` (
  `id` int(11) NOT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `card_type` varchar(255) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `transaction_number` varchar(255) DEFAULT NULL,
  `receiptid` varchar(255) DEFAULT NULL,
  `transaction_type` varchar(255) NOT NULL,
  `ref_num` varchar(255) DEFAULT NULL,
  `response_code` varchar(255) DEFAULT NULL,
  `iso` varchar(255) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `is_visa_debit` varchar(255) DEFAULT NULL,
  `auth_code` varchar(255) DEFAULT NULL,
  `complete` varchar(255) DEFAULT NULL,
  `transaction_date` date DEFAULT NULL,
  `transaction_time` time DEFAULT NULL,
  `ticket` varchar(255) DEFAULT NULL,
  `time_out` varchar(255) DEFAULT NULL,
  `issuer_id` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment_preauth`
--

CREATE TABLE `payment_preauth` (
  `id` int(11) NOT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `payment_pre_id` int(11) DEFAULT NULL,
  `card_type` varchar(255) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `transaction_number` varchar(255) DEFAULT NULL,
  `receiptid` varchar(255) DEFAULT NULL,
  `transaction_type` varchar(255) NOT NULL,
  `ref_num` varchar(255) DEFAULT NULL,
  `response_code` varchar(255) DEFAULT NULL,
  `iso` varchar(255) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `is_visa_debit` varchar(255) DEFAULT NULL,
  `auth_code` varchar(255) DEFAULT NULL,
  `complete` varchar(255) DEFAULT NULL,
  `transaction_date` date DEFAULT NULL,
  `transaction_time` time DEFAULT NULL,
  `ticket` varchar(255) DEFAULT NULL,
  `time_out` varchar(255) DEFAULT NULL,
  `issuer_id` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `recurring_trips`
--

CREATE TABLE `recurring_trips` (
  `id` int(11) NOT NULL,
  `trip_id` int(11) DEFAULT NULL,
  `trip_date` date DEFAULT NULL,
  `status` enum('0','1','2','3') NOT NULL DEFAULT '0' COMMENT '0 Means Pending\r\n1 Means Active\r\n2 Means Completed\r\n3 Means Cancelled',
  `created` datetime DEFAULT current_timestamp(),
  `modified` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `trip_id` int(11) DEFAULT NULL,
  `review` varchar(255) DEFAULT NULL,
  `rating` int(11) DEFAULT NULL,
  `review_by` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0 Means Rider\r\n1 Means Driver',
  `created` datetime DEFAULT current_timestamp(),
  `modified` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `km_radius` int(11) DEFAULT 0,
  `per_km_max_amount` float DEFAULT 0,
  `created` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `km_radius`, `per_km_max_amount`, `created`) VALUES
(1, 5, 0.75, '2022-12-06 11:43:59');

-- --------------------------------------------------------

--
-- Table structure for table `trips`
--

CREATE TABLE `trips` (
  `id` int(11) NOT NULL,
  `trip_request_id` int(11) DEFAULT 0,
  `driver_id` int(11) DEFAULT NULL,
  `from_location` varchar(255) DEFAULT NULL,
  `from_lat` varchar(255) DEFAULT NULL,
  `from_lng` varchar(255) DEFAULT NULL,
  `destination_address` varchar(255) DEFAULT NULL,
  `destination_lat` varchar(255) DEFAULT NULL,
  `destination_lng` varchar(255) DEFAULT NULL,
  `no_of_seat` int(11) DEFAULT NULL,
  `trip_schedule` enum('1','2') DEFAULT NULL COMMENT '1 For One Time\r\n2 For Recurring ',
  `trip_type` enum('1','2') DEFAULT NULL COMMENT '1 Means one way\r\n2 Means Return',
  `departure_date_time` datetime DEFAULT NULL,
  `return_date_time` datetime DEFAULT NULL,
  `price` int(11) DEFAULT 2,
  `vehicle_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `status` enum('0','1','2','3') NOT NULL DEFAULT '0' COMMENT '0 Means inactive\r\n1 Means Active\r\n2 means Completed\r\n3 Means Cancelled',
  `created` datetime DEFAULT current_timestamp(),
  `modified` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `trip_facilities`
--

CREATE TABLE `trip_facilities` (
  `id` int(11) NOT NULL,
  `trip_id` int(11) DEFAULT NULL,
  `luggage_type` enum('1','2','3','4') DEFAULT '1' COMMENT '1 Means No\r\n2 Means Small\r\n3 Means medium\r\n4 Means Large',
  `back_side_seat_for_two_only` tinyint(1) DEFAULT 0 COMMENT '0 Means No\r\n1 Means Yes',
  `smoking_allow` tinyint(1) DEFAULT 0 COMMENT '0 Means No\r\n1 Means Yes',
  `drinking_allow` tinyint(1) DEFAULT 0 COMMENT '0 Means No\r\n1 Means Yes',
  `pets_allow` tinyint(1) DEFAULT 0 COMMENT '0 Means No\r\n1 Means Yes',
  `reach_on_time` tinyint(1) DEFAULT 0 COMMENT '0 Means No\r\n1 Means Yes',
  `wear_face_mask` tinyint(1) DEFAULT 0 COMMENT '0 Means No\r\n1 Means Yes',
  `created` datetime DEFAULT current_timestamp(),
  `modified` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `trip_requests`
--

CREATE TABLE `trip_requests` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `from_address` varchar(255) DEFAULT NULL,
  `from_lat` varchar(255) DEFAULT NULL,
  `from_lng` varchar(255) DEFAULT NULL,
  `destination_address` varchar(255) DEFAULT NULL,
  `destination_lat` varchar(255) DEFAULT NULL,
  `destination_lng` varchar(255) DEFAULT NULL,
  `no_of_seat` int(11) DEFAULT NULL,
  `departure_date_time` datetime DEFAULT NULL,
  `departure_date_time_unix` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT current_timestamp(),
  `modified` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `trip_search_query`
--

CREATE TABLE `trip_search_query` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `user_address` varchar(255) DEFAULT NULL,
  `user_lat` varchar(255) DEFAULT NULL,
  `user_lng` varchar(255) DEFAULT NULL,
  `user_destination_address` varchar(255) DEFAULT NULL,
  `user_destination_lat` varchar(255) DEFAULT NULL,
  `user_destination_lng` varchar(255) DEFAULT NULL,
  `user_departure_date_time` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `trip_stops`
--

CREATE TABLE `trip_stops` (
  `id` int(11) NOT NULL,
  `trip_id` int(11) DEFAULT NULL,
  `destination_address` varchar(255) DEFAULT NULL,
  `destination_lat` varchar(255) DEFAULT NULL,
  `destination_lng` varchar(255) DEFAULT NULL,
  `departure_date_time` datetime DEFAULT NULL,
  `no_of_seat` int(11) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `trip_vehicles`
--

CREATE TABLE `trip_vehicles` (
  `id` int(11) NOT NULL,
  `trip_id` int(11) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  `colour` varchar(255) DEFAULT NULL,
  `registration_number` varchar(255) DEFAULT NULL,
  `status` enum('1','2') NOT NULL DEFAULT '1' COMMENT '1 Means Active\r\n2 Means Incative',
  `created` datetime DEFAULT current_timestamp(),
  `modified` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `middle_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `country_code` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `total_people_drive` int(11) DEFAULT 0,
  `total_ride_taken` int(11) DEFAULT 0,
  `total_km_shard` int(11) DEFAULT 0,
  `social_id` varchar(255) DEFAULT NULL,
  `social_plateform` varchar(255) DEFAULT NULL,
  `profile_pic` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `about` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `forgot_password_otp` varchar(255) DEFAULT NULL,
  `otp_for_mobile` varchar(255) DEFAULT NULL,
  `mobile_verified` tinyint(1) NOT NULL DEFAULT 0,
  `otp_for_email` varchar(255) DEFAULT NULL,
  `email_verified` tinyint(1) NOT NULL DEFAULT 0,
  `is_driver` enum('0','1') NOT NULL DEFAULT '1' COMMENT '0 Means no\r\n1 Means Yes',
  `rating` int(11) DEFAULT NULL,
  `smoking` tinyint(1) DEFAULT NULL,
  `chattingess` varchar(255) DEFAULT NULL,
  `driver_id_verified` tinyint(1) DEFAULT 0,
  `status` enum('0','1','2') NOT NULL DEFAULT '1' COMMENT '1 Means Active\r\n2 Means Inactive\r\n0 Means Block by admin',
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp(),
  `push_notification` tinyint(1) NOT NULL DEFAULT 0,
  `sms_notification` tinyint(1) NOT NULL DEFAULT 0,
  `email_notification` tinyint(1) NOT NULL DEFAULT 0,
  `email_verification_token` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `middle_name`, `last_name`, `email`, `country_code`, `mobile`, `dob`, `total_people_drive`, `total_ride_taken`, `total_km_shard`, `social_id`, `social_plateform`, `profile_pic`, `gender`, `about`, `location`, `password`, `forgot_password_otp`, `otp_for_mobile`, `mobile_verified`, `otp_for_email`, `email_verified`, `is_driver`, `rating`, `smoking`, `chattingess`, `driver_id_verified`, `status`, `created`, `modified`, `push_notification`, `sms_notification`, `email_notification`, `email_verification_token`) VALUES
(1, 'mayank', NULL, 'upa', 'm@gmail.com', NULL, '9001025477', NULL, 0, 0, 0, NULL, NULL, NULL, NULL, NULL, NULL, '$2b$10$2kHguFIEaA2W8npfSKuj5.EZCwgkn5RnqkOk.W9ube/gsmvAhdYwG', NULL, NULL, 2, NULL, 2, '1', NULL, NULL, NULL, 0, '1', '2023-02-15 10:37:47', '2023-02-15 10:37:47', 0, 0, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_verifications`
--

CREATE TABLE `user_verifications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `first_name_as_id` varchar(255) DEFAULT NULL,
  `last_name_as_id` varchar(255) DEFAULT NULL,
  `photo_id_image` varchar(255) DEFAULT NULL,
  `doc_type` varchar(255) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `status` enum('0','1','2') NOT NULL DEFAULT '0' COMMENT '0 Means Pending\r\n1 Means Approved\r\n2 Means Rejected',
  `created` datetime NOT NULL DEFAULT current_timestamp(),
  `modified` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `vehicles`
--

CREATE TABLE `vehicles` (
  `id` int(11) NOT NULL,
  `brand_name` varchar(255) DEFAULT NULL,
  `vehicle_type` varchar(255) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `model_year` varchar(255) DEFAULT NULL,
  `luggage_status` varchar(255) DEFAULT NULL,
  `backrow_seating_status` varchar(255) DEFAULT NULL,
  `others` varchar(255) DEFAULT NULL,
  `registration_number` varchar(255) DEFAULT NULL,
  `model` varchar(255) DEFAULT NULL,
  `total_seat` int(11) DEFAULT NULL,
  `fuel_type` enum('1','2','3','4') DEFAULT '1' COMMENT '1 Means Petrol\r\n2 Means diesel\r\n3 Means Gas\r\n4 Means Electric',
  `ac` enum('1','2') DEFAULT '1' COMMENT '1 Means Yes\r\n2 Means No',
  `driver_id` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1 Means Active\r\n0 Means Inactive',
  `created` datetime DEFAULT current_timestamp(),
  `modified` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `vehicles`
--

INSERT INTO `vehicles` (`id`, `brand_name`, `vehicle_type`, `photo`, `color`, `model_year`, `luggage_status`, `backrow_seating_status`, `others`, `registration_number`, `model`, `total_seat`, `fuel_type`, `ac`, `driver_id`, `status`, `created`, `modified`) VALUES
(2, NULL, 'Hackback', '', 'black', '2022', 'No luaggue', '3 people', 'pets,bikes', 'RJ222', 'New tata nexon', 5, NULL, NULL, 1, 1, '2022-12-01 22:40:34', '2022-12-01 22:40:34'),
(3, NULL, 'Hackback', '', 'black', '2022', 'No luaggue', '3 people', 'pets,bikes', 'RJ222', 'Tata nexon', 5, NULL, NULL, 1, 1, '2022-12-04 09:38:42', '2022-12-04 09:38:42');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `booking_payments`
--
ALTER TABLE `booking_payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `help_menus`
--
ALTER TABLE `help_menus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `help_question_answers`
--
ALTER TABLE `help_question_answers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `issue_documents`
--
ALTER TABLE `issue_documents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `issue_sub_reason`
--
ALTER TABLE `issue_sub_reason`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `offers`
--
ALTER TABLE `offers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_options`
--
ALTER TABLE `payment_options`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_pre`
--
ALTER TABLE `payment_pre`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_preauth`
--
ALTER TABLE `payment_preauth`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `recurring_trips`
--
ALTER TABLE `recurring_trips`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trips`
--
ALTER TABLE `trips`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trip_facilities`
--
ALTER TABLE `trip_facilities`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trip_requests`
--
ALTER TABLE `trip_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trip_search_query`
--
ALTER TABLE `trip_search_query`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trip_stops`
--
ALTER TABLE `trip_stops`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `trip_vehicles`
--
ALTER TABLE `trip_vehicles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_verifications`
--
ALTER TABLE `user_verifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `booking_payments`
--
ALTER TABLE `booking_payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `help_menus`
--
ALTER TABLE `help_menus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `issue_sub_reason`
--
ALTER TABLE `issue_sub_reason`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `offers`
--
ALTER TABLE `offers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment_options`
--
ALTER TABLE `payment_options`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment_pre`
--
ALTER TABLE `payment_pre`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment_preauth`
--
ALTER TABLE `payment_preauth`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `recurring_trips`
--
ALTER TABLE `recurring_trips`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `trips`
--
ALTER TABLE `trips`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `trip_facilities`
--
ALTER TABLE `trip_facilities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `trip_requests`
--
ALTER TABLE `trip_requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `trip_search_query`
--
ALTER TABLE `trip_search_query`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `trip_stops`
--
ALTER TABLE `trip_stops`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `trip_vehicles`
--
ALTER TABLE `trip_vehicles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `user_verifications`
--
ALTER TABLE `user_verifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `vehicles`
--
ALTER TABLE `vehicles`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
