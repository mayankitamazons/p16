const nodemailer = require("nodemailer");
var fs = require("fs");
var handlebars = require("handlebars");
let transport = nodemailer.createTransport({
  host: "smtp.mailtrap.io",
  port: 2525,
  auth: {
    user: "1b2c153084cd20",
    pass: "d9b5e5ad9f437e",
  },
});
var readHTMLFile = function (path, callback) {
  fs.readFile(path, { encoding: "utf-8" }, function (err, html) {
    if (err) {
      callback(err);
    } else {
      callback(null, html);
    }
  });
};

module.exports = {
  sendEmailAfterRegistration(toEmail, first_name) {
    // console.log('inside email send',toEmail);
    try {
      readHTMLFile(
        __dirname + "/template/RegistrationTemplate.html",
        function (err, html) {
          if (err) {
            console.log("error reading file", err);
            return;
          }
          var template = handlebars.compile(html);
          var replacements = {
            first_name: first_name,
          };
          var htmlToSend = template(replacements);
          const token = 123;
          var mailOptions = {
            to: toEmail,
            from: "noreply@humbleride.ca",
            subject: "Welcome to Humble Ride " + first_name,
            html: htmlToSend,
          };
          transport.sendMail(mailOptions, function (err, info) {
            if (err) {
              console.log(err);
            } else {
              // return emailResponse;
              console.log(info);
            }
          });

          return;
        }
      );
    } catch (err) {
      console.log(err);
    }
  },
  sendEmailVerification(toEmail, first_name, verificationCode) {
    // console.log('inside email send',toEmail);
    try {
      readHTMLFile(
        __dirname + "/template/EmailVerificationTemplate.html",
        function (err, html) {
          if (err) {
            console.log("error reading file", err);
            return;
          }
          var template = handlebars.compile(html);
          var replacements = {
            first_name: first_name,
            verificationCode: verificationCode,
          };
          var htmlToSend = template(replacements);
          //   const token = 123;
          var mailOptions = {
            to: toEmail,
            from: "noreply@humbleride.ca",
            subject: "Verifiy Your Email " + first_name,
            html: htmlToSend,
          };
          transport.sendMail(mailOptions, function (err, info) {
            if (err) {
              console.log(err);
            } else {
              // return emailResponse;
              console.log(info);
            }
          });

          return;
        }
      );
    } catch (err) {
      console.log(err);
    }
  },
};
