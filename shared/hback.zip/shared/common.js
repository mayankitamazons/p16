module.exports = {
  validatemobilenumber: function (inputNumber) {
    var phoneno = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
    if (inputNumber.match(phoneno)) {
      return true;
    } else {
      // console.log("message");
      return false;
    }
  },
  removeDuplicates: function (arrToBeFiltered, keyToMatch) {
    let dups = {};
    return arrToBeFiltered.filter(function (item) {
      if (item[keyToMatch] in dups) {
        return false;
      } else {
        dups[item[keyToMatch]] = true;
        return true;
      }
    });
  },
};
