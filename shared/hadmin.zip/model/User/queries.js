const {
  GraphQLList,
  GraphQLID,
  GraphQLString,
  GraphQLNonNull,
  GraphQLFloat,
  GraphQLObjectType,
  GraphQLInt,
} = require("graphql");
const type = require("./type").schema;
const verification_schema = require("./type").verification_schema;
const { validate, ValidationError } = require("validator-fluent");
const { errorName } = require("../../middleware/errorContant");
const GraphQLJSON = require("graphql-type-json").GraphQLJSON;
const UserFunction = require("./function");

// Defines the queries
var c_fields = {
  list: {
    type: GraphQLJSON,
  },
  statusCode: {
    type: GraphQLInt,
  },
  message: {
    type: GraphQLString,
  },
};
var home_schema = new GraphQLObjectType({
  name: "DashboardModel",
  description: "Base model",
  fields: c_fields,
});
module.exports = {
  // users: {
  //   type: new GraphQLList(type),
  //   description: 'Retrieves list of users',
  //   resolve(parent, args) {
  //     return UserFunction.find();
  //   },
  // },
  user: {
    type,
    description: "Retrieves one user",
    args: { user_id: { type: GraphQLID } },
    resolve: async (parent, args, { verifiedUser }) => {
      // resolve(parent, args) {
      if (!verifiedUser) {
        var err = new Error(errorName.UNAUTHRIZED);
        throw err;
        // throw new Error("Unauthenticated");
      } else {
        const [data, errors] = validate(args, (value) => ({
          user_id: value("user_id").notEmpty(),
        }));
        if (Object.keys(errors).length > 0) {
          throw new ValidationError(errors);
        } else {
          args.token_user_id = verifiedUser.user_id;
          return UserFunction.userdetail(args);
        }
      }
    },
  },
  dashboard: {
    type: home_schema,
    description: "Data for dashboard",
    args: {
      user_id: { type: GraphQLInt },
    },
    resolve: async (parent, args, { verifiedUser }) => {
      if (!verifiedUser) {
        var err = new Error(errorName.UNAUTHRIZED);
        throw err;
      } else {
        args.token_user_id = verifiedUser.user_id;
        return UserFunction.dashboard(args);
      }
    },
  },
  userlist: {
    type: home_schema,
    description: "User List",
    args: {
      user_id: { type: GraphQLInt },
      condition: { type: GraphQLJSON },
      // show:allusers, approved_drivers,pending_user_verification,pending_driver_verification, user_with_flagged,suspend_account,
      // closed_account,not_active_user,driver_with_highest_ride,user_with_highest_ride
      limit: { type: GraphQLInt },
      offset: { type: GraphQLInt },
      order: { type: GraphQLJSON },
    },
    resolve: async (parent, args, { verifiedUser }) => {
      if (!verifiedUser) {
        var err = new Error(errorName.UNAUTHRIZED);
        throw err;
      } else {
        args.token_user_id = verifiedUser.user_id;
        return UserFunction.userlist(args);
      }
    },
  },
};
