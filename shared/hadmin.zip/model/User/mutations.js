const {
  GraphQLString,
  GraphQLID,
  GraphQLInt,
  GraphQLBoolean,
  GraphQLNonNull,
} = require("graphql");
const { validate, ValidationError } = require("validator-fluent");
const GraphQLJSON = require("graphql-type-json").GraphQLJSON;
// import { validate, ValidationError } from "validator-fluent";
const type = require("./type").schema;
const verification_schema = require("./type").verification_schema;
const count_schema = require("./type").count_schema;
const common_fields = require("./type").common_fields;
const UserFunction = require("./function");
const { errorName } = require("../../middleware/errorContant");

module.exports = {
  login: {
    type,
    description: "Login user",
    args: {
      email: { type: GraphQLString },
      mobile: { type: GraphQLString },
      password: { type: GraphQLString },
    },
    resolve: async (parent, args) => {
      var go_ahead = true;
       
        const [data, errors] = validate(args, (value) => ({   
          email: value("email").notEmpty().isEmail().isLength({ min: 1, max: 30 }),
          password: value("password").notEmpty().isLength({ min: 8, max: 12 }),
        }));
        if (Object.keys(errors).length > 0) {
          throw new ValidationError(errors);
        } else {
          return UserFunction.login(args);
        }
      
    },
  },
  register: {
    type,
    description: "Register new user",
    args: {
      first_name: { type: GraphQLString },
      middle_name: { type: GraphQLString },
      last_name: { type: GraphQLString },
      mobile: { type: GraphQLString },
      password: { type: GraphQLString },
      country_code: { type: GraphQLString },
      email: { type: GraphQLString },
    },
    resolve: async (parent, args) => {
      console.log("req data", args);
      const [data, errors] = validate(args, (value) => ({
        first_name: value("first_name")
          .notEmpty()
          .isLength({ min: 3, max: 25 }),
        last_name: value("last_name").notEmpty().isLength({ min: 3, max: 25 }),
        email: value("email").isEmail(),
        mobile: value("mobile").isMobilePhone(),
        country_code: value("country_code").isLength({ min: 2, max: 5 }),
        password: value("password").notEmpty().isLength({ min: 8, max: 12 }),
      }));

      if (Object.keys(errors).length > 0) {
        throw new ValidationError(errors);
      } else {
        return UserFunction.register(args);
      }
    },
  },
  changestatus: {
    type,
    description: "update status",
    args: {
      user_id: { type: GraphQLString },
      status: { type: GraphQLString },
      remark: { type: GraphQLString },
    },
    resolve: async (parent, args, { verifiedUser }) => {
      // console.log("req args", args);
      if (!verifiedUser) {
        var err = new Error(errorName.UNAUTHRIZED);
        throw err;
      } else {
        const [data, errors] = validate(args, (value) => ({
          user_id: value("user_id").notEmpty(),
          status: value("status").notEmpty(),
        }));

        if (Object.keys(errors).length > 0) {
          throw new ValidationError(errors);
        } else {
          return UserFunction.changestatus(args);
        }
      }
    },
  },
  changeactivationationstatus: {
    type,
    description: "Activate & Deactivate  Driver Profile",
    args: {
      driver_id: { type: GraphQLInt },
      status: { type: GraphQLString },
      remark: { type: GraphQLString },
    },
    resolve: async (parent, args, { verifiedUser }) => {
      // console.log("req args", args);
      if (!verifiedUser) {
        var err = new Error(errorName.UNAUTHRIZED);
        throw err;
      } else {
        const [data, errors] = validate(args, (value) => ({
          driver_id: value("driver_id").notEmpty(),
          status: value("status").notEmpty(),
        }));

        if (Object.keys(errors).length > 0) {
          throw new ValidationError(errors);
        } else {
          return UserFunction.changeactivationationstatus(args);
        }
      }
    },
  },
   updateuser: {
    type,
    description: 'update user',
    args: {
      first_name: { type: GraphQLString },
      middle_name: { type: GraphQLString },
      last_name: { type: GraphQLString },
      mobile: { type: GraphQLString },
      password: { type: GraphQLString },
      country_code: { type: GraphQLString },
      email: { type: GraphQLString },
      profile_pic: { type: GraphQLString },
      dob: { type: GraphQLString },
      gender: { type: GraphQLString },
      location: { type: GraphQLString },
      about: { type: GraphQLString },
      is_driver: { type: GraphQLBoolean },
      smoking: { type: GraphQLBoolean },
      chattingess: { type: GraphQLString },
    },
    resolve: async (parent, args, { verifiedUser }) => {
      // console.log("req args", args);
      if (!verifiedUser) {
        var err = new Error(errorName.UNAUTHRIZED);
        throw err;
      } else {
        const [data, errors] = validate(args, (value) => ({
          first_name: value('first_name').isLength({ min: 3, max: 25 }),
          middle_name: value('middle_name').isLength({ min: 3, max: 25 }),
          last_name: value('last_name').isLength({ min: 3, max: 25 }),
          email: value('email').isEmail(),
          mobile: value('mobile').isMobilePhone(),
          country_code: value('country_code').isLength({ min: 2, max: 5 }),
          password: value('password').isLength({ min: 8, max: 12 }),
          // about: value('about').isLength({ min: 5, max: 25 }),
        }));

        if (Object.keys(errors).length > 0) {
          throw new ValidationError(errors);
        } else {
          args.user_id = verifiedUser.user_id;
          return UserFunction.updateuser(args);
        }
      }
    },
  },
};
