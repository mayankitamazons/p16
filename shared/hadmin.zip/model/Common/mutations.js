const {
  GraphQLString,
  GraphQLID,
  GraphQLInt,
  GraphQLBoolean,
  GraphQLNonNull,
  GraphQLObjectType,
} = require("graphql");
const { validate, ValidationError } = require("validator-fluent");
const GraphQLJSON = require("graphql-type-json").GraphQLJSON;

const count_schema = require("./type").count_schema;
const CommonFunction = require("./function");
const { errorName } = require("../../middleware/errorContant");

var c_fields = {
  statusCode: {
    type: GraphQLInt,
  },
  message: {
    type: GraphQLString,
  },
};
var update_schema = new GraphQLObjectType({
  name: "Update",
  description: "update",
  fields: c_fields,
});

module.exports = {
  getcount: {
    type: count_schema,
    description: "get count",
    args: {
      table: { type: GraphQLString },
      condition: { type: GraphQLJSON },
    },
    resolve: async (parent, args, { verifiedUser }) => {
      if (!verifiedUser) {
        var err = new Error(errorName.UNAUTHRIZED);
        throw err;
      } else {
        const [data, errors] = validate(args, (value) => ({
          table: value("table").notEmpty(),
          condition: value("condition").notEmpty(),
        }));

        if (Object.keys(errors).length > 0) {
          throw new ValidationError(errors);
        } else {
          return CommonFunction.getcount(args);
        }
      }
    },
  },
  update: {
    type: update_schema,
    description: "update user",
    args: {
      table: { type: GraphQLString },
      condition: { type: GraphQLJSON },
      update: { type: GraphQLJSON },
    },
    resolve: async (parent, args, { verifiedUser }) => {
      if (!verifiedUser) {
        var err = new Error(errorName.UNAUTHRIZED);
        throw err;
      } else {
        const [data, errors] = validate(args, (value) => ({
          table: value("table").notEmpty(),
          condition: value("condition").notEmpty(),
          update: value("update").notEmpty(),
        }));

        if (Object.keys(errors).length > 0) {
          throw new ValidationError(errors);
        } else {
          return CommonFunction.update(args);
        }
      }
    },
  },
  insert: {
    type: update_schema,
    description: "update user",
    args: {
      table: { type: GraphQLString },
      fields: { type: GraphQLJSON },
    },
    resolve: async (parent, args, { verifiedUser }) => {
      if (!verifiedUser) {
        var err = new Error(errorName.UNAUTHRIZED);
        throw err;
      } else {
        const [data, errors] = validate(args, (value) => ({
          table: value("table").notEmpty(),
          fields: value("fields").notEmpty(),
        }));

        if (Object.keys(errors).length > 0) {
          throw new ValidationError(errors);
        } else {
          return CommonFunction.insert(args);
        }
      }
    },
  },
};
