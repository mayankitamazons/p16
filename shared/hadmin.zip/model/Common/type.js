let {
  GraphQLID,
  GraphQLString,
  GraphQLInt,
  GraphQLFloat,
  GraphQLObjectType,
  GraphQLNonNull,
} = require('graphql');
const count_schema = new GraphQLObjectType({
  name: 'TotalRecord',
  description: 'Total Records',
  fields: {
    totalcount:{ type: GraphQLInt },
  },
});
module.exports = {
  count_schema: count_schema,
};
