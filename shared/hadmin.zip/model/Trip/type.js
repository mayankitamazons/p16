let {
  GraphQLID,
  GraphQLString,
  GraphQLInt,
  GraphQLFloat,
  GraphQLObjectType,
  GraphQLNonNull,
} = require('graphql');

var auth_data = {
  userId: {
    type: GraphQLString,
  },
  token: {
    type: GraphQLString,
  },
  tokenExpiration: {
    type: GraphQLInt,
  },
};
const common_fields = {
  id: { type: GraphQLID },
  driver_id: { type: new GraphQLNonNull(GraphQLInt) },
  vehicle_id: { type: GraphQLInt },
  from_location: { type: new GraphQLNonNull(GraphQLString) },
  from_lat: { type: new GraphQLNonNull(GraphQLString) },
  from_lng: { type: new GraphQLNonNull(GraphQLString) },
  destination_address: { type: new GraphQLNonNull(GraphQLString) },
  destination_lat: { type: new GraphQLNonNull(GraphQLString) },
  destination_lng: { type: new GraphQLNonNull(GraphQLString) },
  no_of_seat: { type: GraphQLInt },
  trip_type: { type: GraphQLString, default: '1' },
  departure_date_time: { type: new GraphQLNonNull(GraphQLString) },
  return_date_time: { type: new GraphQLNonNull(GraphQLString) },
  price: { type: GraphQLInt },
  parent_id: { type: GraphQLInt },
  status: { type: GraphQLString, default: '1' },
};
const c_schema = new GraphQLObjectType({
  name: 'Trip',
  description: 'trip type',
  fields: common_fields,
});
const max_price_schema = new GraphQLObjectType({
  name: 'MaxPrice',
  description: 'Max Price for seat',
  fields: {
    total_distance: { type: GraphQLFloat },
    per_km_max_amount: { type: GraphQLFloat },
    max_price: { type: GraphQLFloat }
  },
});
const booking_schema = new GraphQLObjectType({
  name: 'Booking',
  description: 'Booking type',
  fields: {
    id: { type: GraphQLID },
    trip_id: { type: new GraphQLNonNull(GraphQLInt) },
    booked_seat: { type: GraphQLInt },
  from_location: { type: new GraphQLNonNull(GraphQLString) },
  from_lat: { type: new GraphQLNonNull(GraphQLString) },
  from_lng: { type: new GraphQLNonNull(GraphQLString) },
  destination_address: { type: new GraphQLNonNull(GraphQLString) },
  destination_lat: { type: new GraphQLNonNull(GraphQLString) },
  destination_lng: { type: new GraphQLNonNull(GraphQLString) },
  base_fare: { type: GraphQLInt },
  extra_amount: { type: GraphQLInt },
  discount_amount: { type: GraphQLInt },
  total_fare: { type: GraphQLInt },
  coupon_id: { type: GraphQLInt },
  // coupon_code: { type: GraphQLString },
  booking_status: { type: GraphQLString, default: '1' },
  },
});
module.exports = {
  schema: c_schema,
  booking_schema: booking_schema,
  auth_data: auth_data,
  max_price_schema: max_price_schema,
  common_fields: common_fields,
};
