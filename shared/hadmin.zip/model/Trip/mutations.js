const {
  GraphQLString,
  GraphQLID,
  GraphQLInt,
  GraphQLBoolean,
  GraphQLNonNull,
} = require("graphql");
const { validate, ValidationError } = require("validator-fluent");
const type = require("./type").schema;
const booking_schema = require("./type").booking_schema;
const common_fields = require("./type").common_fields;
const TripFunction = require("./function");
const GraphQLJSON = require("graphql-type-json").GraphQLJSON;
const { errorName } = require("../../middleware/errorContant");
const max_price_schema = require("./type").max_price_schema;
module.exports = {};
