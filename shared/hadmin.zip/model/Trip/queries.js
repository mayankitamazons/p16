const {
  GraphQLList,
  GraphQLID,
  GraphQLString,
  GraphQLNonNull,
  GraphQLFloat,
  GraphQLObjectType,
  GraphQLInt,
} = require("graphql");
const type = require("./type").schema;
const GraphQLJSON = require("graphql-type-json").GraphQLJSON;
const { errorName } = require("../../middleware/errorContant");
const { validate, ValidationError } = require("validator-fluent");
// const User = require("./model");
const TripFunction = require("./function");
// const User = require("./users");
// Defines the queries
var c_fields = {
  list: {
    type: GraphQLJSON,
  },
  statusCode: {
    type: GraphQLInt,
  },
  message: {
    type: GraphQLString,
  },
};
var home_schema = new GraphQLObjectType({
  name: "BaseModel",
  description: "Base model",
  fields: c_fields,
});
module.exports = {
  triplist:{
    type: home_schema,
    description: 'Retrieves trips by the riders with type like active completed and concelled as per passed status',
    args: {
      driver_id: { type: GraphQLString },
      status: { type: GraphQLString }
    },
    resolve: async (parent, args, { verifiedUser }) => {
      if (!verifiedUser) {
        var err = new Error(errorName.UNAUTHRIZED);
        throw err;
      } 
      else{
        args.token_user_id = verifiedUser.user_id;
        return TripFunction.triplist(args);
        
      }
     
    },
  },
  gettripdetail: {
    type: home_schema,
    description: 'Retrieves Trip Detail',
    args: {
      trip_id: { type: GraphQLID },
    },
    resolve: async (parent, args, { verifiedUser }) => {
      if (!verifiedUser) {
        var err = new Error(errorName.UNAUTHRIZED);
        throw err;
      } 
      else{
        const [data, errors] = validate(args, (value) => ({
          trip_id: value('trip_id').notEmpty(),
      
          //   trip_type: value("trip_type").notEmpty(),
          //   departure_date_time: value("departure_date_time").notEmpty(),
        }));

        if (Object.keys(errors).length > 0) {
          throw new ValidationError(errors);
        } else {
          args.token_user_id = verifiedUser.user_id;
          return TripFunction.gettripdetail(args);
        }
        
      }
     
    },
  
  },
};
