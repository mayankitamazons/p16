const { GraphQLObjectType } = require("graphql");
const UserMutation = require("../model/User/mutations");
const TripMutation = require("../model/Trip/mutations");
const VehicleMutation = require("../model/Vehicle/mutations");
const CommonMutation = require("../model/Common/mutations");
// const CategoryMutation = require("../model/Category/mutations");
// const CollectionMutation = require("../model/Collection/mutations");
// const LikeMutation = require("../model/Likes/mutations");
module.exports = new GraphQLObjectType({
  name: "RootMutationsType",
  fields: {
    login: UserMutation.login,
    register: UserMutation.register,
    changeuserstatus: UserMutation.changestatus,
    changeactivationationstatus: UserMutation.changeactivationationstatus,
    getcount: CommonMutation.getcount,
    update: CommonMutation.update,
    insert: CommonMutation.insert,
  },
});
